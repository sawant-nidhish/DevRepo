import {
  __commonJS
} from "./chunk-WKYGNSYM.js";

// node_modules/highcharts/modules/stock.js
var require_stock = __commonJS({
  "node_modules/highcharts/modules/stock.js"(exports, module) {
    !/**
    * Highstock JS v11.4.0 (2024-03-04)
    *
    * Highcharts Stock as a plugin for Highcharts
    *
    * (c) 2010-2024 Torstein Honsi
    *
    * License: www.highcharts.com/license
    */
    function(t) {
      "object" == typeof module && module.exports ? (t.default = t, module.exports = t) : "function" == typeof define && define.amd ? define("highcharts/modules/stock", ["highcharts"], function(e) {
        return t(e), t.Highcharts = e, t;
      }) : t("undefined" != typeof Highcharts ? Highcharts : void 0);
    }(function(t) {
      "use strict";
      var e = t ? t._modules : {};
      function i(t2, e2, i2, s) {
        t2.hasOwnProperty(e2) || (t2[e2] = s.apply(null, i2), "function" == typeof CustomEvent && window.dispatchEvent(new CustomEvent("HighchartsModuleLoaded", { detail: { path: e2, module: t2[e2] } })));
      }
      i(e, "Series/DataModifyComposition.js", [e["Core/Axis/Axis.js"], e["Core/Series/Point.js"], e["Core/Series/Series.js"], e["Core/Utilities.js"]], function(t2, e2, i2, s) {
        var o;
        let { tooltipFormatter: r } = e2.prototype, { addEvent: a, arrayMax: n, arrayMin: l, correctFloat: h, defined: d, isArray: p, isNumber: c, isString: u, pick: g } = s;
        return function(t3) {
          function e3(t4, e4, i4) {
            !this.isXAxis && (this.series.forEach(function(i5) {
              "compare" === t4 && "boolean" != typeof e4 ? i5.setCompare(e4, false) : "cumulative" !== t4 || u(e4) || i5.setCumulative(e4, false);
            }), g(i4, true) && this.chart.redraw());
          }
          function i3(t4) {
            let e4 = this, { numberFormatter: i4 } = e4.series.chart, s3 = function(s4) {
              t4 = t4.replace("{point." + s4 + "}", (e4[s4] > 0 && "change" === s4 ? "+" : "") + i4(e4[s4], g(e4.series.tooltipOptions.changeDecimals, 2)));
            };
            return d(e4.change) && s3("change"), d(e4.cumulativeSum) && s3("cumulativeSum"), r.apply(this, [t4]);
          }
          function s2() {
            let t4;
            let e4 = this.options.compare;
            ("percent" === e4 || "value" === e4 || this.options.cumulative) && (t4 = new y(this), "percent" === e4 || "value" === e4 ? t4.initCompare(e4) : t4.initCumulative()), this.dataModify = t4;
          }
          function o2(t4) {
            let e4 = t4.dataExtremes, i4 = e4.activeYData;
            if (this.dataModify && e4) {
              let t5;
              this.options.compare ? t5 = [this.dataModify.modifyValue(e4.dataMin), this.dataModify.modifyValue(e4.dataMax)] : this.options.cumulative && p(i4) && i4.length >= 2 && (t5 = y.getCumulativeExtremes(i4)), t5 && (e4.dataMin = l(t5), e4.dataMax = n(t5));
            }
          }
          function f(t4, e4) {
            this.options.compare = this.userOptions.compare = t4, this.update({}, g(e4, true)), this.dataModify && ("value" === t4 || "percent" === t4) ? this.dataModify.initCompare(t4) : this.points.forEach((t5) => {
              delete t5.change;
            });
          }
          function x() {
            if (this.xAxis && this.processedYData && this.dataModify) {
              let t4 = this.processedXData, e4 = this.processedYData, i4 = e4.length, s3 = true === this.options.compareStart ? 0 : 1, o3 = -1, r2;
              for (this.pointArrayMap && (o3 = this.pointArrayMap.indexOf(this.options.pointValKey || this.pointValKey || "y")), r2 = 0; r2 < i4 - s3; r2++) {
                let i5 = e4[r2] && o3 > -1 ? e4[r2][o3] : e4[r2];
                if (c(i5) && 0 !== i5 && t4[r2 + s3] >= (this.xAxis.min || 0)) {
                  this.dataModify.compareValue = i5;
                  break;
                }
              }
            }
          }
          function m(t4, e4) {
            this.setModifier("compare", t4, e4);
          }
          function b(t4, e4) {
            t4 = g(t4, false), this.options.cumulative = this.userOptions.cumulative = t4, this.update({}, g(e4, true)), this.dataModify ? this.dataModify.initCumulative() : this.points.forEach((t5) => {
              delete t5.cumulativeSum;
            });
          }
          function v(t4, e4) {
            this.setModifier("cumulative", t4, e4);
          }
          t3.compose = function(t4, r2, n2) {
            let l2 = r2.prototype, h2 = n2.prototype, d2 = t4.prototype;
            return d2.setCompare || (d2.setCompare = f, d2.setCumulative = b, a(t4, "afterInit", s2), a(t4, "afterGetExtremes", o2), a(t4, "afterProcessData", x)), l2.setCompare || (l2.setCompare = m, l2.setModifier = e3, l2.setCumulative = v, h2.tooltipFormatter = i3), t4;
          };
          class y {
            constructor(t4) {
              this.series = t4;
            }
            modifyValue() {
              return 0;
            }
            static getCumulativeExtremes(t4) {
              let e4 = 1 / 0, i4 = -1 / 0;
              return t4.reduce((t5, s3) => {
                let o3 = t5 + s3;
                return e4 = Math.min(e4, o3, t5), i4 = Math.max(i4, o3, t5), o3;
              }), [e4, i4];
            }
            initCompare(t4) {
              this.modifyValue = function(e4, i4) {
                null === e4 && (e4 = 0);
                let s3 = this.compareValue;
                if (void 0 !== e4 && void 0 !== s3) {
                  if ("value" === t4 ? e4 -= s3 : e4 = e4 / s3 * 100 - (100 === this.series.options.compareBase ? 0 : 100), void 0 !== i4) {
                    let t5 = this.series.points[i4];
                    t5 && (t5.change = e4);
                  }
                  return e4;
                }
                return 0;
              };
            }
            initCumulative() {
              this.modifyValue = function(t4, e4) {
                if (null === t4 && (t4 = 0), void 0 !== t4 && void 0 !== e4) {
                  let i4 = e4 > 0 ? this.series.points[e4 - 1] : null;
                  i4 && i4.cumulativeSum && (t4 = h(i4.cumulativeSum + t4));
                  let s3 = this.series.points[e4];
                  return s3 && (s3.cumulativeSum = t4), t4;
                }
                return 0;
              };
            }
          }
          t3.Additions = y;
        }(o || (o = {})), o;
      }), i(e, "Stock/Navigator/ChartNavigatorComposition.js", [e["Core/Globals.js"], e["Core/Utilities.js"]], function(t2, e2) {
        let i2;
        let { isTouchDevice: s } = t2, { addEvent: o, merge: r, pick: a } = e2, n = [];
        function l() {
          this.navigator && this.navigator.setBaseSeries(null, false);
        }
        function h() {
          let t3, e3, i3;
          let s2 = this.legend, o2 = this.navigator;
          if (o2) {
            t3 = s2 && s2.options, e3 = o2.xAxis, i3 = o2.yAxis;
            let { scrollbarHeight: r2, scrollButtonSize: n2 } = o2;
            this.inverted ? (o2.left = o2.opposite ? this.chartWidth - r2 - o2.height : this.spacing[3] + r2, o2.top = this.plotTop + n2) : (o2.left = a(e3.left, this.plotLeft + n2), o2.top = o2.navigatorOptions.top || this.chartHeight - o2.height - r2 - (this.scrollbar?.options.margin || 0) - this.spacing[2] - (this.rangeSelector && this.extraBottomMargin ? this.rangeSelector.getHeight() : 0) - (t3 && "bottom" === t3.verticalAlign && "proximate" !== t3.layout && t3.enabled && !t3.floating ? s2.legendHeight + a(t3.margin, 10) : 0) - (this.titleOffset ? this.titleOffset[2] : 0)), e3 && i3 && (this.inverted ? e3.options.left = i3.options.left = o2.left : e3.options.top = i3.options.top = o2.top, e3.setAxisSize(), i3.setAxisSize());
          }
        }
        function d(t3) {
          !this.navigator && !this.scroller && (this.options.navigator.enabled || this.options.scrollbar.enabled) && (this.scroller = this.navigator = new i2(this), a(t3.redraw, true) && this.redraw(t3.animation));
        }
        function p() {
          let t3 = this.options;
          (t3.navigator.enabled || t3.scrollbar.enabled) && (this.scroller = this.navigator = new i2(this));
        }
        function c() {
          let t3 = this.options, e3 = t3.navigator, i3 = t3.rangeSelector;
          if ((e3 && e3.enabled || i3 && i3.enabled) && (!s && "x" === this.zooming.type || s && "x" === this.zooming.pinchType))
            return false;
        }
        function u(t3) {
          let e3 = t3.navigator;
          if (e3 && t3.xAxis[0]) {
            let i3 = t3.xAxis[0].getExtremes();
            e3.render(i3.min, i3.max);
          }
        }
        function g(t3) {
          let e3 = t3.options.navigator || {}, i3 = t3.options.scrollbar || {};
          !this.navigator && !this.scroller && (e3.enabled || i3.enabled) && (r(true, this.options.navigator, e3), r(true, this.options.scrollbar, i3), delete t3.options.navigator, delete t3.options.scrollbar);
        }
        return { compose: function(t3, s2) {
          if (e2.pushUnique(n, t3)) {
            let e3 = t3.prototype;
            i2 = s2, e3.callbacks.push(u), o(t3, "afterAddSeries", l), o(t3, "afterSetChartSize", h), o(t3, "afterUpdate", d), o(t3, "beforeRender", p), o(t3, "beforeShowResetZoom", c), o(t3, "update", g);
          }
        } };
      }), i(e, "Core/Axis/NavigatorAxisComposition.js", [e["Core/Globals.js"], e["Core/Utilities.js"]], function(t2, e2) {
        let { isTouchDevice: i2 } = t2, { addEvent: s, correctFloat: o, defined: r, isNumber: a, pick: n } = e2;
        function l() {
          this.navigatorAxis || (this.navigatorAxis = new d(this));
        }
        function h(t3) {
          let e3;
          let s2 = this.chart, o2 = s2.options, a2 = o2.navigator, n2 = this.navigatorAxis, l2 = s2.zooming.pinchType, h2 = o2.rangeSelector, d2 = s2.zooming.type;
          if (this.isXAxis && (a2?.enabled || h2?.enabled)) {
            if ("y" === d2 && "zoom" === t3.trigger)
              e3 = false;
            else if (("zoom" === t3.trigger && "xy" === d2 || i2 && "xy" === l2) && this.options.range) {
              let e4 = n2.previousZoom;
              r(t3.min) ? n2.previousZoom = [this.min, this.max] : e4 && (t3.min = e4[0], t3.max = e4[1], n2.previousZoom = void 0);
            }
          }
          void 0 !== e3 && t3.preventDefault();
        }
        class d {
          static compose(t3) {
            t3.keepProps.includes("navigatorAxis") || (t3.keepProps.push("navigatorAxis"), s(t3, "init", l), s(t3, "setExtremes", h));
          }
          constructor(t3) {
            this.axis = t3;
          }
          destroy() {
            this.axis = void 0;
          }
          toFixedRange(t3, e3, i3, s2) {
            let l2 = this.axis, h2 = l2.chart, d2 = n(l2.ordinal?.convertOverscroll(l2.options.overscroll), 0), p = n(i3, l2.translate(t3, true, !l2.horiz)), c = n(s2, l2.translate(e3, true, !l2.horiz)), u = h2 && h2.fixedRange, g = (l2.pointRange || 0) / 2;
            if (r(i3) || (p = o(p + g)), r(s2) || (c = o(c - g)), u && l2.dataMin && l2.dataMax) {
              let t4 = l2.dataMax + d2;
              c >= t4 && (p = o(t4 - u), c = o(t4)), p <= l2.dataMin && (c = o(l2.dataMin + u));
            }
            return a(p) && a(c) || (p = c = void 0), { min: p, max: c };
          }
        }
        return d;
      }), i(e, "Stock/Navigator/NavigatorDefaults.js", [e["Core/Color/Color.js"], e["Core/Series/SeriesRegistry.js"]], function(t2, e2) {
        let { parse: i2 } = t2, { seriesTypes: s } = e2;
        return { height: 40, margin: 25, maskInside: true, handles: { width: 7, height: 15, symbols: ["navigator-handle", "navigator-handle"], enabled: true, lineWidth: 1, backgroundColor: "#f2f2f2", borderColor: "#999999" }, maskFill: i2("#667aff").setOpacity(0.3).get(), outlineColor: "#999999", outlineWidth: 1, series: { type: void 0 === s.areaspline ? "line" : "areaspline", fillOpacity: 0.05, lineWidth: 1, compare: null, sonification: { enabled: false }, dataGrouping: { approximation: "average", enabled: true, groupPixelWidth: 2, firstAnchor: "firstPoint", anchor: "middle", lastAnchor: "lastPoint", units: [["millisecond", [1, 2, 5, 10, 20, 25, 50, 100, 200, 500]], ["second", [1, 2, 5, 10, 15, 30]], ["minute", [1, 2, 5, 10, 15, 30]], ["hour", [1, 2, 3, 4, 6, 8, 12]], ["day", [1, 2, 3, 4]], ["week", [1, 2, 3]], ["month", [1, 3, 6]], ["year", null]] }, dataLabels: { enabled: false, zIndex: 2 }, id: "highcharts-navigator-series", className: "highcharts-navigator-series", lineColor: null, marker: { enabled: false }, threshold: null }, xAxis: { className: "highcharts-navigator-xaxis", tickLength: 0, lineWidth: 0, gridLineColor: "#e6e6e6", gridLineWidth: 1, tickPixelInterval: 200, labels: { align: "left", style: { color: "#000000", fontSize: "0.7em", opacity: 0.6, textOutline: "2px contrast" }, x: 3, y: -4 }, crosshair: false }, yAxis: { className: "highcharts-navigator-yaxis", gridLineWidth: 0, startOnTick: false, endOnTick: false, minPadding: 0.1, maxPadding: 0.1, labels: { enabled: false }, crosshair: false, title: { text: null }, tickLength: 0, tickWidth: 0 } };
      }), i(e, "Stock/Navigator/NavigatorSymbols.js", [], function() {
        return { "navigator-handle": function(t2, e2, i2, s, o = {}) {
          let r = o.width ? o.width / 2 : i2, a = Math.round(r / 3) + 0.5;
          return [["M", -r - 1, 0.5], ["L", r, 0.5], ["L", r, (s = o.height || s) + 0.5], ["L", -r - 1, s + 0.5], ["L", -r - 1, 0.5], ["M", -a, 4], ["L", -a, s - 3], ["M", a - 1, 4], ["L", a - 1, s - 3]];
        } };
      }), i(e, "Stock/Utilities/StockUtilities.js", [e["Core/Utilities.js"]], function(t2) {
        let { defined: e2 } = t2;
        return { setFixedRange: function(t3) {
          let i2 = this.xAxis[0];
          e2(i2.dataMax) && e2(i2.dataMin) && t3 ? this.fixedRange = Math.min(t3, i2.dataMax - i2.dataMin) : this.fixedRange = t3;
        } };
      }), i(e, "Stock/Navigator/NavigatorComposition.js", [e["Core/Defaults.js"], e["Core/Globals.js"], e["Core/Axis/NavigatorAxisComposition.js"], e["Stock/Navigator/NavigatorDefaults.js"], e["Stock/Navigator/NavigatorSymbols.js"], e["Core/Renderer/RendererRegistry.js"], e["Stock/Utilities/StockUtilities.js"], e["Core/Utilities.js"]], function(t2, e2, i2, s, o, r, a, n) {
        let { setOptions: l } = t2, { composed: h } = e2, { getRendererType: d } = r, { setFixedRange: p } = a, { addEvent: c, extend: u, pushUnique: g } = n;
        function f() {
          this.chart.navigator && !this.options.isInternal && this.chart.navigator.setBaseSeries(null, false);
        }
        return { compose: function(t3, e3, r2) {
          i2.compose(e3), g(h, "Navigator") && (t3.prototype.setFixedRange = p, u(d().prototype.symbols, o), c(r2, "afterUpdate", f), l({ navigator: s }));
        } };
      }), i(e, "Core/Axis/ScrollbarAxis.js", [e["Core/Globals.js"], e["Core/Utilities.js"]], function(t2, e2) {
        var i2;
        let { composed: s } = t2, { addEvent: o, defined: r, pick: a, pushUnique: n } = e2;
        return function(t3) {
          let e3;
          function i3(t4) {
            let e4 = a(t4.options && t4.options.min, t4.min), i4 = a(t4.options && t4.options.max, t4.max);
            return { axisMin: e4, axisMax: i4, scrollMin: r(t4.dataMin) ? Math.min(e4, t4.min, t4.dataMin, a(t4.threshold, 1 / 0)) : e4, scrollMax: r(t4.dataMax) ? Math.max(i4, t4.max, t4.dataMax, a(t4.threshold, -1 / 0)) : i4 };
          }
          function l() {
            let t4 = this.scrollbar, e4 = t4 && !t4.options.opposite, i4 = this.horiz ? 2 : e4 ? 3 : 1;
            t4 && (this.chart.scrollbarsOffsets = [0, 0], this.chart.axisOffset[i4] += t4.size + (t4.options.margin || 0));
          }
          function h() {
            let t4 = this;
            t4.options && t4.options.scrollbar && t4.options.scrollbar.enabled && (t4.options.scrollbar.vertical = !t4.horiz, t4.options.startOnTick = t4.options.endOnTick = false, t4.scrollbar = new e3(t4.chart.renderer, t4.options.scrollbar, t4.chart), o(t4.scrollbar, "changed", function(e4) {
              let s2, o2;
              let { axisMin: a2, axisMax: n2, scrollMin: l2, scrollMax: h2 } = i3(t4), d2 = h2 - l2;
              if (r(a2) && r(n2)) {
                if (t4.horiz && !t4.reversed || !t4.horiz && t4.reversed ? (s2 = l2 + d2 * this.to, o2 = l2 + d2 * this.from) : (s2 = l2 + d2 * (1 - this.from), o2 = l2 + d2 * (1 - this.to)), this.shouldUpdateExtremes(e4.DOMType)) {
                  let i4 = "mousemove" !== e4.DOMType && "touchmove" !== e4.DOMType && void 0;
                  t4.setExtremes(o2, s2, true, i4, e4);
                } else
                  this.setRange(this.from, this.to);
              }
            }));
          }
          function d() {
            let t4, e4, s2;
            let { scrollMin: o2, scrollMax: a2 } = i3(this), n2 = this.scrollbar, l2 = this.axisTitleMargin + (this.titleOffset || 0), h2 = this.chart.scrollbarsOffsets, d2 = this.options.margin || 0;
            if (n2 && h2) {
              if (this.horiz)
                this.opposite || (h2[1] += l2), n2.position(this.left, this.top + this.height + 2 + h2[1] - (this.opposite ? d2 : 0), this.width, this.height), this.opposite || (h2[1] += d2), t4 = 1;
              else {
                let e5;
                this.opposite && (h2[0] += l2), e5 = n2.options.opposite ? this.left + this.width + 2 + h2[0] - (this.opposite ? 0 : d2) : this.opposite ? 0 : d2, n2.position(e5, this.top, this.width, this.height), this.opposite && (h2[0] += d2), t4 = 0;
              }
              h2[t4] += n2.size + (n2.options.margin || 0), isNaN(o2) || isNaN(a2) || !r(this.min) || !r(this.max) || this.min === this.max ? n2.setRange(0, 1) : (e4 = (this.min - o2) / (a2 - o2), s2 = (this.max - o2) / (a2 - o2), this.horiz && !this.reversed || !this.horiz && this.reversed ? n2.setRange(e4, s2) : n2.setRange(1 - s2, 1 - e4));
            }
          }
          t3.compose = function(t4, i4) {
            n(s, "Axis.Scrollbar") && (e3 = i4, o(t4, "afterGetOffset", l), o(t4, "afterInit", h), o(t4, "afterRender", d));
          };
        }(i2 || (i2 = {})), i2;
      }), i(e, "Stock/Scrollbar/ScrollbarDefaults.js", [], function() {
        return { height: 10, barBorderRadius: 5, buttonBorderRadius: 0, buttonsEnabled: false, liveRedraw: void 0, margin: void 0, minWidth: 6, opposite: true, step: 0.2, zIndex: 3, barBackgroundColor: "#cccccc", barBorderWidth: 0, barBorderColor: "#cccccc", buttonArrowColor: "#333333", buttonBackgroundColor: "#e6e6e6", buttonBorderColor: "#cccccc", buttonBorderWidth: 1, rifleColor: "none", trackBackgroundColor: "rgba(255, 255, 255, 0.001)", trackBorderColor: "#cccccc", trackBorderRadius: 5, trackBorderWidth: 1 };
      }), i(e, "Stock/Scrollbar/Scrollbar.js", [e["Core/Defaults.js"], e["Core/Globals.js"], e["Core/Axis/ScrollbarAxis.js"], e["Stock/Scrollbar/ScrollbarDefaults.js"], e["Core/Utilities.js"]], function(t2, e2, i2, s, o) {
        let { defaultOptions: r } = t2, { addEvent: a, correctFloat: n, defined: l, destroyObjectProperties: h, fireEvent: d, merge: p, pick: c, removeEvent: u } = o;
        class g {
          static compose(t3) {
            i2.compose(t3, g);
          }
          static swapXY(t3, e3) {
            return e3 && t3.forEach((t4) => {
              let e4;
              let i3 = t4.length;
              for (let s2 = 0; s2 < i3; s2 += 2)
                "number" == typeof (e4 = t4[s2 + 1]) && (t4[s2 + 1] = t4[s2 + 2], t4[s2 + 2] = e4);
            }), t3;
          }
          constructor(t3, e3, i3) {
            this._events = [], this.chartX = 0, this.chartY = 0, this.from = 0, this.scrollbarButtons = [], this.scrollbarLeft = 0, this.scrollbarStrokeWidth = 1, this.scrollbarTop = 0, this.size = 0, this.to = 0, this.trackBorderWidth = 1, this.x = 0, this.y = 0, this.init(t3, e3, i3);
          }
          addEvents() {
            let t3 = this.options.inverted ? [1, 0] : [0, 1], e3 = this.scrollbarButtons, i3 = this.scrollbarGroup.element, s2 = this.track.element, o2 = this.mouseDownHandler.bind(this), r2 = this.mouseMoveHandler.bind(this), n2 = this.mouseUpHandler.bind(this), l2 = [[e3[t3[0]].element, "click", this.buttonToMinClick.bind(this)], [e3[t3[1]].element, "click", this.buttonToMaxClick.bind(this)], [s2, "click", this.trackClick.bind(this)], [i3, "mousedown", o2], [i3.ownerDocument, "mousemove", r2], [i3.ownerDocument, "mouseup", n2], [i3, "touchstart", o2], [i3.ownerDocument, "touchmove", r2], [i3.ownerDocument, "touchend", n2]];
            l2.forEach(function(t4) {
              a.apply(null, t4);
            }), this._events = l2;
          }
          buttonToMaxClick(t3) {
            let e3 = (this.to - this.from) * c(this.options.step, 0.2);
            this.updatePosition(this.from + e3, this.to + e3), d(this, "changed", { from: this.from, to: this.to, trigger: "scrollbar", DOMEvent: t3 });
          }
          buttonToMinClick(t3) {
            let e3 = n(this.to - this.from) * c(this.options.step, 0.2);
            this.updatePosition(n(this.from - e3), n(this.to - e3)), d(this, "changed", { from: this.from, to: this.to, trigger: "scrollbar", DOMEvent: t3 });
          }
          cursorToScrollbarPosition(t3) {
            let e3 = this.options, i3 = e3.minWidth > this.calculatedWidth ? e3.minWidth : 0;
            return { chartX: (t3.chartX - this.x - this.xOffset) / (this.barWidth - i3), chartY: (t3.chartY - this.y - this.yOffset) / (this.barWidth - i3) };
          }
          destroy() {
            let t3 = this, e3 = t3.chart.scroller;
            t3.removeEvents(), ["track", "scrollbarRifles", "scrollbar", "scrollbarGroup", "group"].forEach(function(e4) {
              t3[e4] && t3[e4].destroy && (t3[e4] = t3[e4].destroy());
            }), e3 && t3 === e3.scrollbar && (e3.scrollbar = null, h(e3.scrollbarButtons));
          }
          drawScrollbarButton(t3) {
            let e3 = this.renderer, i3 = this.scrollbarButtons, s2 = this.options, o2 = this.size, r2 = e3.g().add(this.group);
            if (i3.push(r2), s2.buttonsEnabled) {
              let a2 = e3.rect().addClass("highcharts-scrollbar-button").add(r2);
              this.chart.styledMode || a2.attr({ stroke: s2.buttonBorderColor, "stroke-width": s2.buttonBorderWidth, fill: s2.buttonBackgroundColor }), a2.attr(a2.crisp({ x: -0.5, y: -0.5, width: o2 + 1, height: o2 + 1, r: s2.buttonBorderRadius }, a2.strokeWidth()));
              let n2 = e3.path(g.swapXY([["M", o2 / 2 + (t3 ? -1 : 1), o2 / 2 - 3], ["L", o2 / 2 + (t3 ? -1 : 1), o2 / 2 + 3], ["L", o2 / 2 + (t3 ? 2 : -2), o2 / 2]], s2.vertical)).addClass("highcharts-scrollbar-arrow").add(i3[t3]);
              this.chart.styledMode || n2.attr({ fill: s2.buttonArrowColor });
            }
          }
          init(t3, e3, i3) {
            this.scrollbarButtons = [], this.renderer = t3, this.userOptions = e3, this.options = p(s, r.scrollbar, e3), this.options.margin = c(this.options.margin, 10), this.chart = i3, this.size = c(this.options.size, this.options.height), e3.enabled && (this.render(), this.addEvents());
          }
          mouseDownHandler(t3) {
            let e3 = this.chart.pointer?.normalize(t3) || t3, i3 = this.cursorToScrollbarPosition(e3);
            this.chartX = i3.chartX, this.chartY = i3.chartY, this.initPositions = [this.from, this.to], this.grabbedCenter = true;
          }
          mouseMoveHandler(t3) {
            let e3;
            let i3 = this.chart.pointer?.normalize(t3) || t3, s2 = this.options.vertical ? "chartY" : "chartX", o2 = this.initPositions || [];
            this.grabbedCenter && (!t3.touches || 0 !== t3.touches[0][s2]) && (e3 = this.cursorToScrollbarPosition(i3)[s2] - this[s2], this.hasDragged = true, this.updatePosition(o2[0] + e3, o2[1] + e3), this.hasDragged && d(this, "changed", { from: this.from, to: this.to, trigger: "scrollbar", DOMType: t3.type, DOMEvent: t3 }));
          }
          mouseUpHandler(t3) {
            this.hasDragged && d(this, "changed", { from: this.from, to: this.to, trigger: "scrollbar", DOMType: t3.type, DOMEvent: t3 }), this.grabbedCenter = this.hasDragged = this.chartX = this.chartY = null;
          }
          position(t3, e3, i3, s2) {
            let { buttonsEnabled: o2, margin: r2 = 0, vertical: a2 } = this.options, n2 = this.rendered ? "animate" : "attr", l2 = s2, h2 = 0;
            this.group.show(), this.x = t3, this.y = e3 + this.trackBorderWidth, this.width = i3, this.height = s2, this.xOffset = l2, this.yOffset = h2, a2 ? (this.width = this.yOffset = i3 = h2 = this.size, this.xOffset = l2 = 0, this.yOffset = h2 = o2 ? this.size : 0, this.barWidth = s2 - (o2 ? 2 * i3 : 0), this.x = t3 += r2) : (this.height = s2 = this.size, this.xOffset = l2 = o2 ? this.size : 0, this.barWidth = i3 - (o2 ? 2 * s2 : 0), this.y = this.y + r2), this.group[n2]({ translateX: t3, translateY: this.y }), this.track[n2]({ width: i3, height: s2 }), this.scrollbarButtons[1][n2]({ translateX: a2 ? 0 : i3 - l2, translateY: a2 ? s2 - h2 : 0 });
          }
          removeEvents() {
            this._events.forEach(function(t3) {
              u.apply(null, t3);
            }), this._events.length = 0;
          }
          render() {
            let t3 = this.renderer, e3 = this.options, i3 = this.size, s2 = this.chart.styledMode, o2 = t3.g("scrollbar").attr({ zIndex: e3.zIndex }).hide().add();
            this.group = o2, this.track = t3.rect().addClass("highcharts-scrollbar-track").attr({ r: e3.trackBorderRadius || 0, height: i3, width: i3 }).add(o2), s2 || this.track.attr({ fill: e3.trackBackgroundColor, stroke: e3.trackBorderColor, "stroke-width": e3.trackBorderWidth });
            let r2 = this.trackBorderWidth = this.track.strokeWidth();
            this.track.attr({ x: -r2 % 2 / 2, y: -r2 % 2 / 2 }), this.scrollbarGroup = t3.g().add(o2), this.scrollbar = t3.rect().addClass("highcharts-scrollbar-thumb").attr({ height: i3 - r2, width: i3 - r2, r: e3.barBorderRadius || 0 }).add(this.scrollbarGroup), this.scrollbarRifles = t3.path(g.swapXY([["M", -3, i3 / 4], ["L", -3, 2 * i3 / 3], ["M", 0, i3 / 4], ["L", 0, 2 * i3 / 3], ["M", 3, i3 / 4], ["L", 3, 2 * i3 / 3]], e3.vertical)).addClass("highcharts-scrollbar-rifles").add(this.scrollbarGroup), s2 || (this.scrollbar.attr({ fill: e3.barBackgroundColor, stroke: e3.barBorderColor, "stroke-width": e3.barBorderWidth }), this.scrollbarRifles.attr({ stroke: e3.rifleColor, "stroke-width": 1 })), this.scrollbarStrokeWidth = this.scrollbar.strokeWidth(), this.scrollbarGroup.translate(-this.scrollbarStrokeWidth % 2 / 2, -this.scrollbarStrokeWidth % 2 / 2), this.drawScrollbarButton(0), this.drawScrollbarButton(1);
          }
          setRange(t3, e3) {
            let i3, s2;
            let o2 = this.options, r2 = o2.vertical, a2 = o2.minWidth, h2 = this.barWidth, d2 = !this.rendered || this.hasDragged || this.chart.navigator && this.chart.navigator.hasDragged ? "attr" : "animate";
            if (!l(h2))
              return;
            let p2 = h2 * Math.min(e3, 1);
            i3 = Math.ceil(h2 * (t3 = Math.max(t3, 0))), this.calculatedWidth = s2 = n(p2 - i3), s2 < a2 && (i3 = (h2 - a2 + s2) * t3, s2 = a2);
            let c2 = Math.floor(i3 + this.xOffset + this.yOffset), u2 = s2 / 2 - 0.5;
            this.from = t3, this.to = e3, r2 ? (this.scrollbarGroup[d2]({ translateY: c2 }), this.scrollbar[d2]({ height: s2 }), this.scrollbarRifles[d2]({ translateY: u2 }), this.scrollbarTop = c2, this.scrollbarLeft = 0) : (this.scrollbarGroup[d2]({ translateX: c2 }), this.scrollbar[d2]({ width: s2 }), this.scrollbarRifles[d2]({ translateX: u2 }), this.scrollbarLeft = c2, this.scrollbarTop = 0), s2 <= 12 ? this.scrollbarRifles.hide() : this.scrollbarRifles.show(), false === o2.showFull && (t3 <= 0 && e3 >= 1 ? this.group.hide() : this.group.show()), this.rendered = true;
          }
          shouldUpdateExtremes(t3) {
            return c(this.options.liveRedraw, e2.svg && !e2.isTouchDevice && !this.chart.boosted) || "mouseup" === t3 || "touchend" === t3 || !l(t3);
          }
          trackClick(t3) {
            let e3 = this.chart.pointer?.normalize(t3) || t3, i3 = this.to - this.from, s2 = this.y + this.scrollbarTop, o2 = this.x + this.scrollbarLeft;
            this.options.vertical && e3.chartY > s2 || !this.options.vertical && e3.chartX > o2 ? this.updatePosition(this.from + i3, this.to + i3) : this.updatePosition(this.from - i3, this.to - i3), d(this, "changed", { from: this.from, to: this.to, trigger: "scrollbar", DOMEvent: t3 });
          }
          update(t3) {
            this.destroy(), this.init(this.chart.renderer, p(true, this.options, t3), this.chart);
          }
          updatePosition(t3, e3) {
            e3 > 1 && (t3 = n(1 - n(e3 - t3)), e3 = 1), t3 < 0 && (e3 = n(e3 - t3), t3 = 0), this.from = t3, this.to = e3;
          }
        }
        return g.defaultOptions = s, r.scrollbar = p(true, g.defaultOptions, r.scrollbar), g;
      }), i(e, "Stock/Navigator/Navigator.js", [e["Core/Axis/Axis.js"], e["Stock/Navigator/ChartNavigatorComposition.js"], e["Core/Defaults.js"], e["Core/Globals.js"], e["Core/Axis/NavigatorAxisComposition.js"], e["Stock/Navigator/NavigatorComposition.js"], e["Stock/Scrollbar/Scrollbar.js"], e["Core/Utilities.js"]], function(t2, e2, i2, s, o, r, a, n) {
        let { defaultOptions: l } = i2, { isTouchDevice: h } = s, { addEvent: d, clamp: p, correctFloat: c, defined: u, destroyObjectProperties: g, erase: f, extend: x, find: m, fireEvent: b, isArray: v, isNumber: y, merge: M, pick: S, removeEvent: A, splat: k } = n;
        function C(t3, ...e3) {
          let i3 = [].filter.call(e3, y);
          if (i3.length)
            return Math[t3].apply(0, i3);
        }
        class D {
          static compose(t3, i3, s2) {
            e2.compose(t3, D), r.compose(t3, i3, s2);
          }
          constructor(t3) {
            this.scrollbarHeight = 0, this.init(t3);
          }
          drawHandle(t3, e3, i3, s2) {
            let o2 = this.navigatorOptions.handles.height;
            this.handles[e3][s2](i3 ? { translateX: Math.round(this.left + this.height / 2), translateY: Math.round(this.top + parseInt(t3, 10) + 0.5 - o2) } : { translateX: Math.round(this.left + parseInt(t3, 10)), translateY: Math.round(this.top + this.height / 2 - o2 / 2 - 1) });
          }
          drawOutline(t3, e3, i3, s2) {
            let o2 = this.navigatorOptions.maskInside, r2 = this.outline.strokeWidth(), a2 = r2 / 2, n2 = r2 % 2 / 2, l2 = this.scrollButtonSize, h2 = this.size, d2 = this.top, p2 = this.height, c2 = d2 - a2, u2 = d2 + p2, g2 = this.left, f2, x2;
            i3 ? (f2 = d2 + e3 + n2, e3 = d2 + t3 + n2, x2 = [["M", g2 + p2, d2 - l2 - n2], ["L", g2 + p2, f2], ["L", g2, f2], ["M", g2, e3], ["L", g2 + p2, e3], ["L", g2 + p2, d2 + h2 + l2]], o2 && x2.push(["M", g2 + p2, f2 - a2], ["L", g2 + p2, e3 + a2])) : (g2 -= l2, t3 += g2 + l2 - n2, e3 += g2 + l2 - n2, x2 = [["M", g2, c2], ["L", t3, c2], ["L", t3, u2], ["M", e3, u2], ["L", e3, c2], ["L", g2 + h2 + 2 * l2, d2 + a2]], o2 && x2.push(["M", t3 - a2, c2], ["L", e3 + a2, c2])), this.outline[s2]({ d: x2 });
          }
          drawMasks(t3, e3, i3, s2) {
            let o2, r2, a2, n2;
            let l2 = this.left, h2 = this.top, d2 = this.height;
            i3 ? (a2 = [l2, l2, l2], n2 = [h2, h2 + t3, h2 + e3], r2 = [d2, d2, d2], o2 = [t3, e3 - t3, this.size - e3]) : (a2 = [l2, l2 + t3, l2 + e3], n2 = [h2, h2, h2], r2 = [t3, e3 - t3, this.size - e3], o2 = [d2, d2, d2]), this.shades.forEach((t4, e4) => {
              t4[s2]({ x: a2[e4], y: n2[e4], width: r2[e4], height: o2[e4] });
            });
          }
          renderElements() {
            let t3 = this, e3 = t3.navigatorOptions, i3 = e3.maskInside, s2 = t3.chart, o2 = s2.inverted, r2 = s2.renderer, a2 = { cursor: o2 ? "ns-resize" : "ew-resize" }, n2 = t3.navigatorGroup = r2.g("navigator").attr({ zIndex: 8, visibility: "hidden" }).add();
            if ([!i3, i3, !i3].forEach((i4, o3) => {
              let l2 = r2.rect().addClass("highcharts-navigator-mask" + (1 === o3 ? "-inside" : "-outside")).add(n2);
              s2.styledMode || (l2.attr({ fill: i4 ? e3.maskFill : "rgba(0,0,0,0)" }), 1 === o3 && l2.css(a2)), t3.shades[o3] = l2;
            }), t3.outline = r2.path().addClass("highcharts-navigator-outline").add(n2), s2.styledMode || t3.outline.attr({ "stroke-width": e3.outlineWidth, stroke: e3.outlineColor }), e3.handles && e3.handles.enabled) {
              let i4 = e3.handles, { height: o3, width: l2 } = i4;
              [0, 1].forEach((e4) => {
                t3.handles[e4] = r2.symbol(i4.symbols[e4], -l2 / 2 - 1, 0, l2, o3, i4), s2.inverted && t3.handles[e4].attr({ rotation: 90, rotationOriginX: Math.floor(-l2 / 2), rotationOriginY: (o3 + l2) / 2 }), t3.handles[e4].attr({ zIndex: 7 - e4 }).addClass("highcharts-navigator-handle highcharts-navigator-handle-" + ["left", "right"][e4]).add(n2), s2.styledMode || t3.handles[e4].attr({ fill: i4.backgroundColor, stroke: i4.borderColor, "stroke-width": i4.lineWidth }).css(a2);
              });
            }
          }
          update(t3) {
            (this.series || []).forEach((t4) => {
              t4.baseSeries && delete t4.baseSeries.navigatorSeries;
            }), this.destroy(), M(true, this.chart.options.navigator, t3), this.init(this.chart);
          }
          render(t3, e3, i3, s2) {
            let o2 = this.chart, r2 = this.xAxis, a2 = r2.pointRange || 0, n2 = r2.navigatorAxis.fake ? o2.xAxis[0] : r2, l2 = this.navigatorEnabled, h2 = this.rendered, d2 = o2.inverted, g2 = o2.xAxis[0].minRange, f2 = o2.xAxis[0].options.maxRange, x2 = this.scrollButtonSize, m2, v2, M2, A2 = this.scrollbarHeight, k2, C2;
            if (this.hasDragged && !u(i3))
              return;
            if (t3 = c(t3 - a2 / 2), e3 = c(e3 + a2 / 2), !y(t3) || !y(e3)) {
              if (!h2)
                return;
              i3 = 0, s2 = S(r2.width, n2.width);
            }
            this.left = S(r2.left, o2.plotLeft + x2 + (d2 ? o2.plotWidth : 0));
            let D2 = this.size = k2 = S(r2.len, (d2 ? o2.plotHeight : o2.plotWidth) - 2 * x2);
            m2 = d2 ? A2 : k2 + 2 * x2, i3 = S(i3, r2.toPixels(t3, true)), s2 = S(s2, r2.toPixels(e3, true)), y(i3) && Math.abs(i3) !== 1 / 0 || (i3 = 0, s2 = m2);
            let w = r2.toValue(i3, true), O = r2.toValue(s2, true), B = Math.abs(c(O - w));
            B < g2 ? this.grabbedLeft ? i3 = r2.toPixels(O - g2 - a2, true) : this.grabbedRight && (s2 = r2.toPixels(w + g2 + a2, true)) : u(f2) && c(B - a2) > f2 && (this.grabbedLeft ? i3 = r2.toPixels(O - f2 - a2, true) : this.grabbedRight && (s2 = r2.toPixels(w + f2 + a2, true))), this.zoomedMax = p(Math.max(i3, s2), 0, D2), this.zoomedMin = p(this.fixedWidth ? this.zoomedMax - this.fixedWidth : Math.min(i3, s2), 0, D2), this.range = this.zoomedMax - this.zoomedMin, D2 = Math.round(this.zoomedMax);
            let E = Math.round(this.zoomedMin);
            l2 && (this.navigatorGroup.attr({ visibility: "inherit" }), C2 = h2 && !this.hasDragged ? "animate" : "attr", this.drawMasks(E, D2, d2, C2), this.drawOutline(E, D2, d2, C2), this.navigatorOptions.handles.enabled && (this.drawHandle(E, 0, d2, C2), this.drawHandle(D2, 1, d2, C2))), this.scrollbar && (d2 ? (M2 = this.top - x2, v2 = this.left - A2 + (l2 || !n2.opposite ? 0 : (n2.titleOffset || 0) + n2.axisTitleMargin), A2 = k2 + 2 * x2) : (M2 = this.top + (l2 ? this.height : -A2), v2 = this.left - x2), this.scrollbar.position(v2, M2, m2, A2), this.scrollbar.setRange(this.zoomedMin / (k2 || 1), this.zoomedMax / (k2 || 1))), this.rendered = true, b(this, "afterRender");
          }
          addMouseEvents() {
            let t3 = this, e3 = t3.chart, i3 = e3.container, s2 = [], o2, r2;
            t3.mouseMoveHandler = o2 = function(e4) {
              t3.onMouseMove(e4);
            }, t3.mouseUpHandler = r2 = function(e4) {
              t3.onMouseUp(e4);
            }, (s2 = t3.getPartsEvents("mousedown")).push(d(e3.renderTo, "mousemove", o2), d(i3.ownerDocument, "mouseup", r2), d(e3.renderTo, "touchmove", o2), d(i3.ownerDocument, "touchend", r2)), s2.concat(t3.getPartsEvents("touchstart")), t3.eventsToUnbind = s2, t3.series && t3.series[0] && s2.push(d(t3.series[0].xAxis, "foundExtremes", function() {
              e3.navigator.modifyNavigatorAxisExtremes();
            }));
          }
          getPartsEvents(t3) {
            let e3 = this, i3 = [];
            return ["shades", "handles"].forEach(function(s2) {
              e3[s2].forEach(function(o2, r2) {
                i3.push(d(o2.element, t3, function(t4) {
                  e3[s2 + "Mousedown"](t4, r2);
                }));
              });
            }), i3;
          }
          shadesMousedown(t3, e3) {
            t3 = this.chart.pointer?.normalize(t3) || t3;
            let i3 = this.chart, s2 = this.xAxis, o2 = this.zoomedMin, r2 = this.size, a2 = this.range, n2 = this.left, l2 = t3.chartX, h2, d2, p2, c2;
            i3.inverted && (l2 = t3.chartY, n2 = this.top), 1 === e3 ? (this.grabbedCenter = l2, this.fixedWidth = a2, this.dragOffset = l2 - o2) : (c2 = l2 - n2 - a2 / 2, 0 === e3 ? c2 = Math.max(0, c2) : 2 === e3 && c2 + a2 >= r2 && (c2 = r2 - a2, this.reversedExtremes ? (c2 -= a2, d2 = this.getUnionExtremes().dataMin) : h2 = this.getUnionExtremes().dataMax), c2 !== o2 && (this.fixedWidth = a2, u((p2 = s2.navigatorAxis.toFixedRange(c2, c2 + a2, d2, h2)).min) && b(this, "setRange", { min: Math.min(p2.min, p2.max), max: Math.max(p2.min, p2.max), redraw: true, eventArguments: { trigger: "navigator" } })));
          }
          handlesMousedown(t3, e3) {
            t3 = this.chart.pointer?.normalize(t3) || t3;
            let i3 = this.chart, s2 = i3.xAxis[0], o2 = this.reversedExtremes;
            0 === e3 ? (this.grabbedLeft = true, this.otherHandlePos = this.zoomedMax, this.fixedExtreme = o2 ? s2.min : s2.max) : (this.grabbedRight = true, this.otherHandlePos = this.zoomedMin, this.fixedExtreme = o2 ? s2.max : s2.min), i3.setFixedRange(void 0);
          }
          onMouseMove(t3) {
            let e3 = this, i3 = e3.chart, s2 = e3.navigatorSize, o2 = e3.range, r2 = e3.dragOffset, a2 = i3.inverted, n2 = e3.left, l2;
            (!t3.touches || 0 !== t3.touches[0].pageX) && (l2 = (t3 = i3.pointer?.normalize(t3) || t3).chartX, a2 && (n2 = e3.top, l2 = t3.chartY), e3.grabbedLeft ? (e3.hasDragged = true, e3.render(0, 0, l2 - n2, e3.otherHandlePos)) : e3.grabbedRight ? (e3.hasDragged = true, e3.render(0, 0, e3.otherHandlePos, l2 - n2)) : e3.grabbedCenter && (e3.hasDragged = true, l2 < r2 ? l2 = r2 : l2 > s2 + r2 - o2 && (l2 = s2 + r2 - o2), e3.render(0, 0, l2 - r2, l2 - r2 + o2)), e3.hasDragged && e3.scrollbar && S(e3.scrollbar.options.liveRedraw, !h && !this.chart.boosted) && (t3.DOMType = t3.type, setTimeout(function() {
              e3.onMouseUp(t3);
            }, 0)));
          }
          onMouseUp(t3) {
            let e3, i3, s2, o2, r2, a2;
            let n2 = this.chart, l2 = this.xAxis, h2 = this.scrollbar, d2 = t3.DOMEvent || t3, p2 = n2.inverted, c2 = this.rendered && !this.hasDragged ? "animate" : "attr";
            (this.hasDragged && (!h2 || !h2.hasDragged) || "scrollbar" === t3.trigger) && (s2 = this.getUnionExtremes(), this.zoomedMin === this.otherHandlePos ? o2 = this.fixedExtreme : this.zoomedMax === this.otherHandlePos && (r2 = this.fixedExtreme), this.zoomedMax === this.size && (r2 = this.reversedExtremes ? s2.dataMin : s2.dataMax), 0 === this.zoomedMin && (o2 = this.reversedExtremes ? s2.dataMax : s2.dataMin), u((a2 = l2.navigatorAxis.toFixedRange(this.zoomedMin, this.zoomedMax, o2, r2)).min) && b(this, "setRange", { min: Math.min(a2.min, a2.max), max: Math.max(a2.min, a2.max), redraw: true, animation: !this.hasDragged && null, eventArguments: { trigger: "navigator", triggerOp: "navigator-drag", DOMEvent: d2 } })), "mousemove" !== t3.DOMType && "touchmove" !== t3.DOMType && (this.grabbedLeft = this.grabbedRight = this.grabbedCenter = this.fixedWidth = this.fixedExtreme = this.otherHandlePos = this.hasDragged = this.dragOffset = null), this.navigatorEnabled && y(this.zoomedMin) && y(this.zoomedMax) && (i3 = Math.round(this.zoomedMin), e3 = Math.round(this.zoomedMax), this.shades && this.drawMasks(i3, e3, p2, c2), this.outline && this.drawOutline(i3, e3, p2, c2), this.navigatorOptions.handles.enabled && Object.keys(this.handles).length === this.handles.length && (this.drawHandle(i3, 0, p2, c2), this.drawHandle(e3, 1, p2, c2)));
          }
          removeEvents() {
            this.eventsToUnbind && (this.eventsToUnbind.forEach(function(t3) {
              t3();
            }), this.eventsToUnbind = void 0), this.removeBaseSeriesEvents();
          }
          removeBaseSeriesEvents() {
            let t3 = this.baseSeries || [];
            this.navigatorEnabled && t3[0] && (false !== this.navigatorOptions.adaptToUpdatedData && t3.forEach(function(t4) {
              A(t4, "updatedData", this.updatedDataHandler);
            }, this), t3[0].xAxis && A(t3[0].xAxis, "foundExtremes", this.modifyBaseAxisExtremes));
          }
          init(e3) {
            let i3 = e3.options, s2 = i3.navigator || {}, r2 = s2.enabled, n2 = i3.scrollbar || {}, l2 = n2.enabled, h2 = r2 && s2.height || 0, p2 = l2 && n2.height || 0, c2 = n2.buttonsEnabled && p2 || 0;
            this.handles = [], this.shades = [], this.chart = e3, this.setBaseSeries(), this.height = h2, this.scrollbarHeight = p2, this.scrollButtonSize = c2, this.scrollbarEnabled = l2, this.navigatorEnabled = r2, this.navigatorOptions = s2, this.scrollbarOptions = n2, this.opposite = S(s2.opposite, !!(!r2 && e3.inverted));
            let u2 = this, g2 = u2.baseSeries, f2 = e3.xAxis.length, x2 = e3.yAxis.length, m2 = g2 && g2[0] && g2[0].xAxis || e3.xAxis[0] || { options: {} };
            if (e3.isDirtyBox = true, u2.navigatorEnabled ? (u2.xAxis = new t2(e3, M({ breaks: m2.options.breaks, ordinal: m2.options.ordinal, overscroll: m2.options.overscroll }, s2.xAxis, { id: "navigator-x-axis", yAxis: "navigator-y-axis", type: "datetime", index: f2, isInternal: true, offset: 0, keepOrdinalPadding: true, startOnTick: false, endOnTick: false, minPadding: 0, maxPadding: 0, zoomEnabled: false }, e3.inverted ? { offsets: [c2, 0, -c2, 0], width: h2 } : { offsets: [0, -c2, 0, c2], height: h2 }), "xAxis"), u2.yAxis = new t2(e3, M(s2.yAxis, { id: "navigator-y-axis", alignTicks: false, offset: 0, index: x2, isInternal: true, reversed: S(s2.yAxis && s2.yAxis.reversed, e3.yAxis[0] && e3.yAxis[0].reversed, false), zoomEnabled: false }, e3.inverted ? { width: h2 } : { height: h2 }), "yAxis"), g2 || s2.series.data ? u2.updateNavigatorSeries(false) : 0 === e3.series.length && (u2.unbindRedraw = d(e3, "beforeRedraw", function() {
              e3.series.length > 0 && !u2.series && (u2.setBaseSeries(), u2.unbindRedraw());
            })), u2.reversedExtremes = e3.inverted && !u2.xAxis.reversed || !e3.inverted && u2.xAxis.reversed, u2.renderElements(), u2.addMouseEvents()) : (u2.xAxis = { chart: e3, navigatorAxis: { fake: true }, translate: function(t3, i4) {
              let s3 = e3.xAxis[0], o2 = s3.getExtremes(), r3 = s3.len - 2 * c2, a2 = C("min", s3.options.min, o2.dataMin), n3 = C("max", s3.options.max, o2.dataMax) - a2;
              return i4 ? t3 * n3 / r3 + a2 : r3 * (t3 - a2) / n3;
            }, toPixels: function(t3) {
              return this.translate(t3);
            }, toValue: function(t3) {
              return this.translate(t3, true);
            } }, u2.xAxis.navigatorAxis.axis = u2.xAxis, u2.xAxis.navigatorAxis.toFixedRange = o.prototype.toFixedRange.bind(u2.xAxis.navigatorAxis)), e3.options.scrollbar.enabled) {
              let t3 = M(e3.options.scrollbar, { vertical: e3.inverted });
              !y(t3.margin) && u2.navigatorEnabled && (t3.margin = e3.inverted ? -3 : 3), e3.scrollbar = u2.scrollbar = new a(e3.renderer, t3, e3), d(u2.scrollbar, "changed", function(t4) {
                let e4 = u2.size, i4 = e4 * this.to, s3 = e4 * this.from;
                u2.hasDragged = u2.scrollbar.hasDragged, u2.render(0, 0, s3, i4), this.shouldUpdateExtremes(t4.DOMType) && setTimeout(function() {
                  u2.onMouseUp(t4);
                });
              });
            }
            u2.addBaseSeriesEvents(), u2.addChartEvents();
          }
          getUnionExtremes(t3) {
            let e3;
            let i3 = this.chart.xAxis[0], s2 = this.xAxis, o2 = s2.options, r2 = i3.options;
            return t3 && null === i3.dataMin || (e3 = { dataMin: S(o2 && o2.min, C("min", r2.min, i3.dataMin, s2.dataMin, s2.min)), dataMax: S(o2 && o2.max, C("max", r2.max, i3.dataMax, s2.dataMax, s2.max)) }), e3;
          }
          setBaseSeries(t3, e3) {
            let i3 = this.chart, s2 = this.baseSeries = [];
            t3 = t3 || i3.options && i3.options.navigator.baseSeries || (i3.series.length ? m(i3.series, (t4) => !t4.options.isInternal).index : 0), (i3.series || []).forEach((e4, i4) => {
              !e4.options.isInternal && (e4.options.showInNavigator || (i4 === t3 || e4.options.id === t3) && false !== e4.options.showInNavigator) && s2.push(e4);
            }), this.xAxis && !this.xAxis.navigatorAxis.fake && this.updateNavigatorSeries(true, e3);
          }
          updateNavigatorSeries(t3, e3) {
            let i3 = this, s2 = i3.chart, o2 = i3.baseSeries, r2 = { enableMouseTracking: false, index: null, linkedTo: null, group: "nav", padXAxis: false, xAxis: "navigator-x-axis", yAxis: "navigator-y-axis", showInLegend: false, stacking: void 0, isInternal: true, states: { inactive: { opacity: 1 } } }, a2 = i3.series = (i3.series || []).filter((t4) => {
              let e4 = t4.baseSeries;
              return !(0 > o2.indexOf(e4)) || (e4 && (A(e4, "updatedData", i3.updatedDataHandler), delete e4.navigatorSeries), t4.chart && t4.destroy(), false);
            }), n2, h2, d2 = i3.navigatorOptions.series, p2;
            o2 && o2.length && o2.forEach((t4) => {
              let c2 = t4.navigatorSeries, u2 = x({ color: t4.color, visible: t4.visible }, v(d2) ? l.navigator.series : d2);
              if (c2 && false === i3.navigatorOptions.adaptToUpdatedData)
                return;
              r2.name = "Navigator " + o2.length, p2 = (n2 = t4.options || {}).navigatorOptions || {}, u2.dataLabels = k(u2.dataLabels), (h2 = M(n2, r2, u2, p2)).pointRange = S(u2.pointRange, p2.pointRange, l.plotOptions[h2.type || "line"].pointRange);
              let g2 = p2.data || u2.data;
              i3.hasNavigatorData = i3.hasNavigatorData || !!g2, h2.data = g2 || n2.data && n2.data.slice(0), c2 && c2.options ? c2.update(h2, e3) : (t4.navigatorSeries = s2.initSeries(h2), s2.setSortedData(), t4.navigatorSeries.baseSeries = t4, a2.push(t4.navigatorSeries));
            }), (d2.data && !(o2 && o2.length) || v(d2)) && (i3.hasNavigatorData = false, (d2 = k(d2)).forEach((t4, e4) => {
              r2.name = "Navigator " + (a2.length + 1), (h2 = M(l.navigator.series, { color: s2.series[e4] && !s2.series[e4].options.isInternal && s2.series[e4].color || s2.options.colors[e4] || s2.options.colors[0] }, r2, t4)).data = t4.data, h2.data && (i3.hasNavigatorData = true, a2.push(s2.initSeries(h2)));
            })), t3 && this.addBaseSeriesEvents();
          }
          addBaseSeriesEvents() {
            let t3 = this, e3 = t3.baseSeries || [];
            e3[0] && e3[0].xAxis && e3[0].eventsToUnbind.push(d(e3[0].xAxis, "foundExtremes", this.modifyBaseAxisExtremes)), e3.forEach((e4) => {
              e4.eventsToUnbind.push(d(e4, "show", function() {
                this.navigatorSeries && this.navigatorSeries.setVisible(true, false);
              })), e4.eventsToUnbind.push(d(e4, "hide", function() {
                this.navigatorSeries && this.navigatorSeries.setVisible(false, false);
              })), false !== this.navigatorOptions.adaptToUpdatedData && e4.xAxis && e4.eventsToUnbind.push(d(e4, "updatedData", this.updatedDataHandler)), e4.eventsToUnbind.push(d(e4, "remove", function() {
                this.navigatorSeries && (f(t3.series, this.navigatorSeries), u(this.navigatorSeries.options) && this.navigatorSeries.remove(false), delete this.navigatorSeries);
              }));
            });
          }
          getBaseSeriesMin(t3) {
            return this.baseSeries.reduce(function(t4, e3) {
              return Math.min(t4, e3.xData && e3.xData.length ? e3.xData[0] : t4);
            }, t3);
          }
          modifyNavigatorAxisExtremes() {
            let t3 = this.xAxis;
            if (void 0 !== t3.getExtremes) {
              let e3 = this.getUnionExtremes(true);
              e3 && (e3.dataMin !== t3.min || e3.dataMax !== t3.max) && (t3.min = e3.dataMin, t3.max = e3.dataMax);
            }
          }
          modifyBaseAxisExtremes() {
            let t3, e3;
            let i3 = this.chart.navigator, s2 = this.getExtremes(), o2 = s2.min, r2 = s2.max, a2 = s2.dataMin, n2 = s2.dataMax, l2 = r2 - o2, h2 = i3.stickToMin, d2 = i3.stickToMax, p2 = S(this.ordinal?.convertOverscroll(this.options.overscroll), 0), c2 = i3.series && i3.series[0], u2 = !!this.setExtremes;
            !(this.eventArgs && "rangeSelectorButton" === this.eventArgs.trigger) && (h2 && (t3 = (e3 = a2) + l2), d2 && (t3 = n2 + p2, h2 || (e3 = Math.max(a2, t3 - l2, i3.getBaseSeriesMin(c2 && c2.xData ? c2.xData[0] : -Number.MAX_VALUE)))), u2 && (h2 || d2) && y(e3) && (this.min = this.userMin = e3, this.max = this.userMax = t3)), i3.stickToMin = i3.stickToMax = null;
          }
          updatedDataHandler() {
            let t3 = this.chart.navigator, e3 = this.navigatorSeries, i3 = t3.reversedExtremes ? 0 === Math.round(t3.zoomedMin) : Math.round(t3.zoomedMax) >= Math.round(t3.size);
            t3.stickToMax = S(this.chart.options.navigator && this.chart.options.navigator.stickToMax, i3), t3.stickToMin = t3.shouldStickToMin(this, t3), e3 && !t3.hasNavigatorData && (e3.options.pointStart = this.xData[0], e3.setData(this.options.data, false, null, false));
          }
          shouldStickToMin(t3, e3) {
            let i3 = e3.getBaseSeriesMin(t3.xData[0]), s2 = t3.xAxis, o2 = s2.max, r2 = s2.min, a2 = s2.options.range;
            return !!(y(o2) && y(r2)) && (a2 && o2 - i3 > 0 ? o2 - i3 < a2 : r2 <= i3);
          }
          addChartEvents() {
            this.eventsToUnbind || (this.eventsToUnbind = []), this.eventsToUnbind.push(d(this.chart, "redraw", function() {
              let t3 = this.navigator, e3 = t3 && (t3.baseSeries && t3.baseSeries[0] && t3.baseSeries[0].xAxis || this.xAxis[0]);
              e3 && t3.render(e3.min, e3.max);
            }), d(this.chart, "getMargins", function() {
              let t3 = this.navigator, e3 = t3.opposite ? "plotTop" : "marginBottom";
              this.inverted && (e3 = t3.opposite ? "marginRight" : "plotLeft"), this[e3] = (this[e3] || 0) + (t3.navigatorEnabled || !this.inverted ? t3.height + t3.scrollbarHeight : 0) + t3.navigatorOptions.margin;
            }), d(D, "setRange", function(t3) {
              this.chart.xAxis[0].setExtremes(t3.min, t3.max, t3.redraw, t3.animation, t3.eventArguments);
            }));
          }
          destroy() {
            this.removeEvents(), this.xAxis && (f(this.chart.xAxis, this.xAxis), f(this.chart.axes, this.xAxis)), this.yAxis && (f(this.chart.yAxis, this.yAxis), f(this.chart.axes, this.yAxis)), (this.series || []).forEach((t3) => {
              t3.destroy && t3.destroy();
            }), ["series", "xAxis", "yAxis", "shades", "outline", "scrollbarTrack", "scrollbarRifles", "scrollbarGroup", "scrollbar", "navigatorGroup", "rendered"].forEach((t3) => {
              this[t3] && this[t3].destroy && this[t3].destroy(), this[t3] = null;
            }), [this.handles].forEach((t3) => {
              g(t3);
            });
          }
        }
        return D;
      }), i(e, "Core/Axis/OrdinalAxis.js", [e["Core/Axis/Axis.js"], e["Core/Globals.js"], e["Core/Series/Series.js"], e["Core/Utilities.js"]], function(t2, e2, i2, s) {
        var o;
        let { addEvent: r, correctFloat: a, css: n, defined: l, error: h, isNumber: d, pick: p, timeUnits: c, isString: u } = s;
        return function(t3) {
          function s2(t4, e3, i3, s3, o3 = [], r2 = 0, a2) {
            let n2 = {}, d2 = this.options.tickPixelInterval, p2 = this.chart.time, u2 = [], g2, f2, x2, m2, b2, v2 = 0, y2 = [], M2 = -Number.MAX_VALUE;
            if (!this.options.ordinal && !this.options.breaks || !o3 || o3.length < 3 || void 0 === e3)
              return p2.getTimeTicks.apply(p2, arguments);
            let S2 = o3.length;
            for (g2 = 0; g2 < S2; g2++) {
              if (b2 = g2 && o3[g2 - 1] > i3, o3[g2] < e3 && (v2 = g2), g2 === S2 - 1 || o3[g2 + 1] - o3[g2] > 5 * r2 || b2) {
                if (o3[g2] > M2) {
                  for (f2 = p2.getTimeTicks(t4, o3[v2], o3[g2], s3); f2.length && f2[0] <= M2; )
                    f2.shift();
                  f2.length && (M2 = f2[f2.length - 1]), u2.push(y2.length), y2 = y2.concat(f2);
                }
                v2 = g2 + 1;
              }
              if (b2)
                break;
            }
            if (f2) {
              if (m2 = f2.info, a2 && m2.unitRange <= c.hour) {
                for (v2 = 1, g2 = y2.length - 1; v2 < g2; v2++)
                  p2.dateFormat("%d", y2[v2]) !== p2.dateFormat("%d", y2[v2 - 1]) && (n2[y2[v2]] = "day", x2 = true);
                x2 && (n2[y2[0]] = "day"), m2.higherRanks = n2;
              }
              m2.segmentStarts = u2, y2.info = m2;
            } else
              h(12, false, this.chart);
            if (a2 && l(d2)) {
              let t5 = y2.length, e4 = [], s4 = [], o4, r3, a3, l2, h2, p3 = t5;
              for (; p3--; )
                r3 = this.translate(y2[p3]), a3 && (s4[p3] = a3 - r3), e4[p3] = a3 = r3;
              for (s4.sort(), (l2 = s4[Math.floor(s4.length / 2)]) < 0.6 * d2 && (l2 = null), p3 = y2[t5 - 1] > i3 ? t5 - 1 : t5, a3 = void 0; p3--; )
                h2 = Math.abs(a3 - (r3 = e4[p3])), a3 && h2 < 0.8 * d2 && (null === l2 || h2 < 0.8 * l2) ? (n2[y2[p3]] && !n2[y2[p3 + 1]] ? (o4 = p3 + 1, a3 = r3) : o4 = p3, y2.splice(o4, 1)) : a3 = r3;
            }
            return y2;
          }
          function o2(t4) {
            let e3 = this.ordinal.positions;
            if (!e3)
              return t4;
            let i3 = e3.length - 1, s3;
            return (t4 < 0 ? t4 = e3[0] : t4 > i3 ? t4 = e3[i3] : (i3 = Math.floor(t4), s3 = t4 - i3), void 0 !== s3 && void 0 !== e3[i3]) ? e3[i3] + (s3 ? s3 * (e3[i3 + 1] - e3[i3]) : 0) : t4;
          }
          function g(t4) {
            let e3 = this.ordinal, i3 = this.old ? this.old.min : this.min, s3 = this.old ? this.old.transA : this.transA, o3 = e3.getExtendedPositions();
            if (o3 && o3.length) {
              let r2 = a((t4 - i3) * s3 + this.minPixelPadding), n2 = a(e3.getIndexOfPoint(r2, o3)), l2 = a(n2 % 1);
              if (n2 >= 0 && n2 <= o3.length - 1) {
                let t5 = o3[Math.floor(n2)], e4 = o3[Math.ceil(n2)];
                return o3[Math.floor(n2)] + l2 * (e4 - t5);
              }
            }
            return t4;
          }
          function f(e3, i3) {
            let s3 = t3.Additions.findIndexOf(e3, i3, true);
            if (e3[s3] === i3)
              return s3;
            let o3 = (i3 - e3[s3]) / (e3[s3 + 1] - e3[s3]);
            return s3 + o3;
          }
          function x() {
            this.ordinal || (this.ordinal = new t3.Additions(this));
          }
          function m() {
            let { eventArgs: t4, options: e3 } = this;
            if (this.isXAxis && l(e3.overscroll) && 0 !== e3.overscroll && d(this.max) && d(this.min) && (this.options.ordinal && !this.ordinal.originalOrdinalRange && this.ordinal.getExtendedPositions(false), this.max === this.dataMax && (t4?.trigger !== "pan" || this.isInternal) && t4?.trigger !== "navigator")) {
              let i3 = this.ordinal.convertOverscroll(e3.overscroll);
              this.max += i3, !this.isInternal && l(this.userMin) && t4?.trigger !== "mousewheel" && (this.min += i3);
            }
          }
          function b() {
            this.horiz && !this.isDirty && (this.isDirty = this.isOrdinal && this.chart.navigator && !this.chart.navigator.adaptToUpdatedData);
          }
          function v() {
            this.ordinal && (this.ordinal.beforeSetTickPositions(), this.tickInterval = this.ordinal.postProcessTickInterval(this.tickInterval));
          }
          function y(t4) {
            let e3 = this.xAxis[0], i3 = e3.ordinal.convertOverscroll(e3.options.overscroll), s3 = t4.originalEvent.chartX, o3 = this.options.chart.panning, r2 = false;
            if (o3 && "y" !== o3.type && e3.options.ordinal && e3.series.length) {
              let t5, o4;
              let a2 = this.mouseDownX, l2 = e3.getExtremes(), h2 = l2.dataMax, d2 = l2.min, p2 = l2.max, c2 = this.hoverPoints, u2 = e3.closestPointRange || e3.ordinal && e3.ordinal.overscrollPointsRange, g2 = Math.round((a2 - s3) / (e3.translationSlope * (e3.ordinal.slope || u2))), f2 = e3.ordinal.getExtendedPositions(), x2 = { ordinal: { positions: f2, extendedOrdinalPositions: f2 } }, m2 = e3.index2val, b2 = e3.val2lin;
              x2.ordinal.positions ? Math.abs(g2) > 1 && (c2 && c2.forEach(function(t6) {
                t6.setState();
              }), h2 > (o4 = x2.ordinal.positions)[o4.length - 1] && o4.push(h2), this.setFixedRange(p2 - d2), (t5 = e3.navigatorAxis.toFixedRange(void 0, void 0, m2.apply(x2, [b2.apply(x2, [d2, true]) + g2]), m2.apply(x2, [b2.apply(x2, [p2, true]) + g2]))).min >= Math.min(l2.dataMin, d2) && t5.max <= Math.max(h2, p2) + i3 && e3.setExtremes(t5.min, t5.max, true, false, { trigger: "pan" }), this.mouseDownX = s3, n(this.container, { cursor: "move" })) : r2 = true;
            } else
              r2 = true;
            r2 || o3 && /y/.test(o3.type) ? i3 && (e3.max = e3.dataMax + i3) : t4.preventDefault();
          }
          function M() {
            let t4 = this.xAxis;
            t4 && t4.options.ordinal && (delete t4.ordinal.index, delete t4.ordinal.originalOrdinalRange);
          }
          function S(t4, e3) {
            let i3;
            let s3 = this.ordinal, o3 = s3.positions, r2 = s3.slope, a2;
            if (!o3)
              return t4;
            let n2 = o3.length;
            if (o3[0] <= t4 && o3[n2 - 1] >= t4)
              i3 = f(o3, t4);
            else {
              if (!((a2 = s3.getExtendedPositions && s3.getExtendedPositions()) && a2.length))
                return t4;
              let n3 = a2.length;
              r2 || (r2 = (a2[n3 - 1] - a2[0]) / n3);
              let l2 = f(a2, o3[0]);
              if (t4 >= a2[0] && t4 <= a2[n3 - 1])
                i3 = f(a2, t4) - l2;
              else {
                if (!e3)
                  return t4;
                i3 = t4 < a2[0] ? -l2 - (a2[0] - t4) / r2 : (t4 - a2[n3 - 1]) / r2 + n3 - l2;
              }
            }
            return e3 ? i3 : r2 * (i3 || 0) + s3.offset;
          }
          t3.compose = function(t4, e3, i3) {
            let a2 = t4.prototype;
            return a2.ordinal2lin || (a2.getTimeTicks = s2, a2.index2val = o2, a2.lin2val = g, a2.val2lin = S, a2.ordinal2lin = a2.val2lin, r(t4, "afterInit", x), r(t4, "foundExtremes", m), r(t4, "afterSetScale", b), r(t4, "initialAxisTranslation", v), r(i3, "pan", y), r(e3, "updatedData", M)), t4;
          };
          class A {
            constructor(t4) {
              this.index = {}, this.axis = t4;
            }
            beforeSetTickPositions() {
              let t4 = this.axis, e3 = t4.ordinal, i3 = t4.getExtremes(), s3 = i3.min, o3 = i3.max, r2 = t4.brokenAxis?.hasBreaks, a2 = t4.options.ordinal, n2, l2, h2, d2, c2, u2, g2, f2 = [], x2 = Number.MAX_VALUE, m2 = false, b2 = false, v2 = false;
              if (a2 || r2) {
                let i4 = 0;
                if (t4.series.forEach(function(t5, e4) {
                  if (l2 = [], e4 > 0 && "highcharts-navigator-series" !== t5.options.id && t5.processedXData.length > 1 && (b2 = i4 !== t5.processedXData[1] - t5.processedXData[0]), i4 = t5.processedXData[1] - t5.processedXData[0], t5.boosted && (v2 = t5.boosted), t5.reserveSpace() && (false !== t5.takeOrdinalPosition || r2) && (n2 = (f2 = f2.concat(t5.processedXData)).length, f2.sort(function(t6, e5) {
                    return t6 - e5;
                  }), x2 = Math.min(x2, p(t5.closestPointRange, x2)), n2)) {
                    for (e4 = 0; e4 < n2 - 1; )
                      f2[e4] !== f2[e4 + 1] && l2.push(f2[e4 + 1]), e4++;
                    l2[0] !== f2[0] && l2.unshift(f2[0]), f2 = l2;
                  }
                }), t4.ordinal.originalOrdinalRange || (t4.ordinal.originalOrdinalRange = (f2.length - 1) * x2), b2 && v2 && (f2.pop(), f2.shift()), (n2 = f2.length) > 2) {
                  for (h2 = f2[1] - f2[0], g2 = n2 - 1; g2-- && !m2; )
                    f2[g2 + 1] - f2[g2] !== h2 && (m2 = true);
                  !t4.options.keepOrdinalPadding && (f2[0] - s3 > h2 || o3 - f2[f2.length - 1] > h2) && (m2 = true);
                } else
                  t4.options.overscroll && (2 === n2 ? x2 = f2[1] - f2[0] : 1 === n2 ? (x2 = t4.ordinal.convertOverscroll(t4.options.overscroll), f2 = [f2[0], f2[0] + x2]) : x2 = e3.overscrollPointsRange);
                m2 || t4.forceOrdinal ? (t4.options.overscroll && (e3.overscrollPointsRange = x2, f2 = f2.concat(e3.getOverscrollPositions())), e3.positions = f2, d2 = t4.ordinal2lin(Math.max(s3, f2[0]), true), c2 = Math.max(t4.ordinal2lin(Math.min(o3, f2[f2.length - 1]), true), 1), e3.slope = u2 = (o3 - s3) / (c2 - d2), e3.offset = s3 - d2 * u2) : (e3.overscrollPointsRange = p(t4.closestPointRange, e3.overscrollPointsRange), e3.positions = t4.ordinal.slope = e3.offset = void 0);
              }
              t4.isOrdinal = a2 && m2, e3.groupIntervalFactor = null;
            }
            static findIndexOf(t4, e3, i3) {
              let s3 = 0, o3 = t4.length - 1, r2;
              for (; s3 < o3; )
                t4[r2 = Math.ceil((s3 + o3) / 2)] <= e3 ? s3 = r2 : o3 = r2 - 1;
              return t4[s3] === e3 ? s3 : i3 ? s3 : -1;
            }
            getExtendedPositions(t4 = true) {
              let s3 = this, o3 = s3.axis, r2 = o3.constructor.prototype, a2 = o3.chart, n2 = o3.series[0]?.currentDataGrouping, l2 = n2 ? n2.count + n2.unitName : "raw", h2 = t4 ? o3.ordinal.convertOverscroll(o3.options.overscroll) : 0, d2 = o3.getExtremes(), p2, c2, u2 = s3.index;
              return u2 || (u2 = s3.index = {}), u2[l2] || ((p2 = { series: [], chart: a2, forceOrdinal: false, getExtremes: function() {
                return { min: d2.dataMin, max: d2.dataMax + h2 };
              }, applyGrouping: r2.applyGrouping, getGroupPixelWidth: r2.getGroupPixelWidth, getTimeTicks: r2.getTimeTicks, options: { ordinal: true }, ordinal: { getGroupIntervalFactor: this.getGroupIntervalFactor }, ordinal2lin: r2.ordinal2lin, getIndexOfPoint: r2.getIndexOfPoint, val2lin: r2.val2lin }).ordinal.axis = p2, o3.series.forEach(function(o4) {
                c2 = { xAxis: p2, xData: o4.xData.slice(), chart: a2, groupPixelWidth: o4.groupPixelWidth, destroyGroupedData: e2.noop, getProcessedData: i2.prototype.getProcessedData, applyGrouping: i2.prototype.applyGrouping, reserveSpace: i2.prototype.reserveSpace, visible: o4.visible }, t4 && (c2.xData = c2.xData.concat(s3.getOverscrollPositions())), c2.options = { dataGrouping: n2 ? { firstAnchor: "firstPoint", anchor: "middle", lastAnchor: "lastPoint", enabled: true, forced: true, approximation: "open", units: [[n2.unitName, [n2.count]]] } : { enabled: false } }, p2.series.push(c2), o4.processData.apply(c2);
              }), p2.applyGrouping({ hasExtremesChanged: true }), c2?.closestPointRange !== c2?.basePointRange && c2.currentDataGrouping && (p2.forceOrdinal = true), o3.ordinal.beforeSetTickPositions.apply({ axis: p2 }), !o3.ordinal.originalOrdinalRange && p2.ordinal.originalOrdinalRange && (o3.ordinal.originalOrdinalRange = p2.ordinal.originalOrdinalRange), u2[l2] = p2.ordinal.positions), u2[l2];
            }
            getGroupIntervalFactor(t4, e3, i3) {
              let s3 = i3.processedXData, o3 = s3.length, r2 = [], a2, n2, l2 = this.groupIntervalFactor;
              if (!l2) {
                for (n2 = 0; n2 < o3 - 1; n2++)
                  r2[n2] = s3[n2 + 1] - s3[n2];
                r2.sort(function(t5, e4) {
                  return t5 - e4;
                }), a2 = r2[Math.floor(o3 / 2)], t4 = Math.max(t4, s3[0]), e3 = Math.min(e3, s3[o3 - 1]), this.groupIntervalFactor = l2 = o3 * a2 / (e3 - t4);
              }
              return l2;
            }
            getIndexOfPoint(t4, e3) {
              let i3;
              let s3 = this.axis, o3 = 0, r2 = function(t5) {
                let { min: e4, max: i4 } = s3;
                return !!(l(e4) && l(i4)) && t5.points.some((t6) => t6.x >= e4 && t6.x <= i4);
              };
              s3.series.forEach((t5) => {
                let e4 = t5.points?.[0];
                l(e4?.plotX) && (e4.plotX < i3 || !l(i3)) && r2(t5) && (i3 = e4.plotX, o3 = e4.x);
              }), i3 ?? (i3 = s3.minPixelPadding);
              let n2 = s3.translationSlope * (this.slope || s3.closestPointRange || this.overscrollPointsRange), h2 = a((t4 - i3) / n2);
              return A.findIndexOf(e3, o3, true) + h2;
            }
            getOverscrollPositions() {
              let t4 = this.axis, e3 = this.convertOverscroll(t4.options.overscroll), i3 = this.overscrollPointsRange, s3 = [], o3 = t4.dataMax;
              if (l(i3))
                for (; o3 <= t4.dataMax + e3; )
                  s3.push(o3 += i3);
              return s3;
            }
            postProcessTickInterval(t4) {
              let e3 = this.axis, i3 = this.slope;
              return i3 ? e3.options.breaks ? e3.closestPointRange || t4 : t4 / (i3 / e3.closestPointRange) : t4;
            }
            convertOverscroll(t4 = 0) {
              let e3 = this, i3 = e3.axis, s3 = function(t5) {
                return p(e3.originalOrdinalRange, l(i3.dataMax) && l(i3.dataMin) ? i3.dataMax - i3.dataMin : 0) * t5;
              };
              if (u(t4)) {
                let e4 = parseInt(t4, 10);
                if (/%$/.test(t4))
                  return s3(e4 / 100);
                if (/px/.test(t4)) {
                  let t5 = Math.min(e4, 0.9 * i3.len) / i3.len;
                  return s3(t5 / (1 - t5));
                }
                return 0;
              }
              return t4;
            }
          }
          t3.Additions = A;
        }(o || (o = {})), o;
      }), i(e, "Stock/RangeSelector/RangeSelectorDefaults.js", [], function() {
        return { lang: { rangeSelectorZoom: "Zoom", rangeSelectorFrom: "", rangeSelectorTo: "→" }, rangeSelector: { allButtonsEnabled: false, buttons: void 0, buttonSpacing: 5, dropdown: "responsive", enabled: void 0, verticalAlign: "top", buttonTheme: { width: 28, height: 18, padding: 2, zIndex: 7 }, floating: false, x: 0, y: 0, height: void 0, inputBoxBorderColor: "none", inputBoxHeight: 17, inputBoxWidth: void 0, inputDateFormat: "%e %b %Y", inputDateParser: void 0, inputEditDateFormat: "%Y-%m-%d", inputEnabled: true, inputPosition: { align: "right", x: 0, y: 0 }, inputSpacing: 5, selected: void 0, buttonPosition: { align: "left", x: 0, y: 0 }, inputStyle: { color: "#334eff", cursor: "pointer", fontSize: "0.8em" }, labelStyle: { color: "#666666", fontSize: "0.8em" } } };
      }), i(e, "Stock/RangeSelector/RangeSelectorComposition.js", [e["Core/Defaults.js"], e["Core/Globals.js"], e["Stock/RangeSelector/RangeSelectorDefaults.js"], e["Core/Utilities.js"]], function(t2, e2, i2, s) {
        let o;
        let { defaultOptions: r } = t2, { composed: a } = e2, { addEvent: n, defined: l, extend: h, find: d, isNumber: p, merge: c, pick: u, pushUnique: g } = s, f = [];
        function x() {
          let t3, e3;
          let i3 = this.range, s2 = i3.type, o2 = this.max, r2 = this.chart.time, a2 = function(t4, e4) {
            let i4 = "year" === s2 ? "FullYear" : "Month", o3 = new r2.Date(t4), a3 = r2.get(i4, o3);
            return r2.set(i4, o3, a3 + e4), a3 === r2.get(i4, o3) && r2.set("Date", o3, 0), o3.getTime() - t4;
          };
          p(i3) ? (t3 = o2 - i3, e3 = i3) : i3 && (t3 = o2 + a2(o2, -(i3.count || 1)), this.chart && this.chart.setFixedRange(o2 - t3));
          let n2 = u(this.dataMin, Number.MIN_VALUE);
          return p(t3) || (t3 = n2), t3 <= n2 && (t3 = n2, void 0 === e3 && (e3 = a2(t3, i3.count)), this.newMax = Math.min(t3 + e3, u(this.dataMax, Number.MAX_VALUE))), p(o2) ? !p(i3) && i3 && i3._offsetMin && (t3 += i3._offsetMin) : t3 = void 0, t3;
        }
        function m() {
          this.options.rangeSelector && this.options.rangeSelector.enabled && (this.rangeSelector = new o(this));
        }
        function b() {
          let t3 = this.axes, e3 = this.rangeSelector;
          if (e3) {
            p(e3.deferredYTDClick) && (e3.clickButton(e3.deferredYTDClick), delete e3.deferredYTDClick), t3.forEach((t4) => {
              t4.updateNames(), t4.setScale();
            }), this.getAxisMargins(), e3.render();
            let i3 = e3.options.verticalAlign;
            e3.options.floating || ("bottom" === i3 ? this.extraBottomMargin = true : "middle" === i3 || (this.extraTopMargin = true));
          }
        }
        function v(t3) {
          let e3, i3, s2, o2;
          let r2 = t3.rangeSelector, a2 = () => {
            r2 && (e3 = t3.xAxis[0].getExtremes(), i3 = t3.legend, o2 = r2 && r2.options.verticalAlign, p(e3.min) && r2.render(e3.min, e3.max), i3.display && "top" === o2 && o2 === i3.options.verticalAlign && (s2 = c(t3.spacingBox), "vertical" === i3.options.layout ? s2.y = t3.plotTop : s2.y += r2.getHeight(), i3.group.placed = false, i3.align(s2)));
          };
          r2 && (d(f, (e4) => e4[0] === t3) || f.push([t3, [n(t3.xAxis[0], "afterSetExtremes", function(t4) {
            r2 && r2.render(t4.min, t4.max);
          }), n(t3, "redraw", a2)]]), a2());
        }
        function y() {
          for (let t3 = 0, e3 = f.length; t3 < e3; ++t3) {
            let e4 = f[t3];
            if (e4[0] === this) {
              e4[1].forEach((t4) => t4()), f.splice(t3, 1);
              return;
            }
          }
        }
        function M() {
          let t3 = this.rangeSelector;
          if (t3) {
            let e3 = t3.getHeight();
            this.extraTopMargin && (this.plotTop += e3), this.extraBottomMargin && (this.marginBottom += e3);
          }
        }
        function S() {
          let t3 = this.rangeSelector;
          if (t3 && !t3.options.floating) {
            t3.render();
            let e3 = t3.options.verticalAlign;
            "bottom" === e3 ? this.extraBottomMargin = true : "middle" !== e3 && (this.extraTopMargin = true);
          }
        }
        function A(t3) {
          let e3 = t3.options.rangeSelector, i3 = this.extraBottomMargin, s2 = this.extraTopMargin, r2 = this.rangeSelector;
          if (e3 && e3.enabled && !l(r2) && this.options.rangeSelector && (this.options.rangeSelector.enabled = true, this.rangeSelector = r2 = new o(this)), this.extraBottomMargin = false, this.extraTopMargin = false, r2) {
            v(this);
            let t4 = e3 && e3.verticalAlign || r2.options && r2.options.verticalAlign;
            r2.options.floating || ("bottom" === t4 ? this.extraBottomMargin = true : "middle" === t4 || (this.extraTopMargin = true)), (this.extraBottomMargin !== i3 || this.extraTopMargin !== s2) && (this.isDirtyBox = true);
          }
        }
        return { compose: function(t3, e3, s2) {
          if (o = s2, g(a, "RangeSelector")) {
            let s3 = e3.prototype;
            t3.prototype.minFromRange = x, n(e3, "afterGetContainer", m), n(e3, "beforeRender", b), n(e3, "destroy", y), n(e3, "getMargins", M), n(e3, "render", S), n(e3, "update", A), s3.callbacks.push(v), h(r, { rangeSelector: i2.rangeSelector }), h(r.lang, i2.lang);
          }
        } };
      }), i(e, "Stock/RangeSelector/RangeSelector.js", [e["Core/Axis/Axis.js"], e["Core/Defaults.js"], e["Core/Globals.js"], e["Stock/RangeSelector/RangeSelectorComposition.js"], e["Core/Renderer/SVG/SVGElement.js"], e["Core/Utilities.js"]], function(t2, e2, i2, s, o, r) {
        let { defaultOptions: a } = e2, { addEvent: n, createElement: l, css: h, defined: d, destroyObjectProperties: p, discardElement: c, extend: u, fireEvent: g, isNumber: f, merge: x, objectEach: m, pad: b, pick: v, pInt: y, splat: M } = r;
        class S {
          static compose(t3, e3) {
            s.compose(t3, e3, S);
          }
          constructor(t3) {
            this.buttonOptions = S.prototype.defaultButtons, this.initialButtonGroupWidth = 0, this.chart = t3, this.init(t3);
          }
          clickButton(e3, i3) {
            let s2 = this.chart, o2 = this.buttonOptions[e3], r2 = s2.xAxis[0], a2 = s2.scroller && s2.scroller.getUnionExtremes() || r2 || {}, l2 = o2.type, h2 = o2.dataGrouping, p2 = a2.dataMin, c2 = a2.dataMax, u2, x2 = r2 && Math.round(Math.min(r2.max, v(c2, r2.max))), m2, b2 = o2._range, y2, S2, A, k, C, D = true;
            if (null !== p2 && null !== c2) {
              if (this.setSelected(e3), h2 && (this.forcedDataGrouping = true, t2.prototype.setDataGrouping.call(r2 || { chart: this.chart }, h2, false), this.frozenStates = o2.preserveDataGrouping), "month" === l2 || "year" === l2)
                r2 ? (k = { range: o2, max: x2, chart: s2, dataMin: p2, dataMax: c2 }, u2 = r2.minFromRange.call(k), f(k.newMax) && (x2 = k.newMax), D = false) : b2 = o2;
              else if (b2)
                x2 = Math.min((u2 = Math.max(x2 - b2, p2)) + b2, c2), D = false;
              else if ("ytd" === l2) {
                if (r2)
                  (void 0 === c2 || void 0 === p2) && (p2 = Number.MAX_VALUE, c2 = Number.MIN_VALUE, s2.series.forEach((t3) => {
                    let e4 = t3.xData;
                    e4 && (p2 = Math.min(e4[0], p2), c2 = Math.max(e4[e4.length - 1], c2));
                  }), i3 = false), u2 = y2 = (C = this.getYTDExtremes(c2, p2, s2.time.useUTC)).min, x2 = C.max;
                else {
                  this.deferredYTDClick = e3;
                  return;
                }
              } else
                "all" === l2 && r2 && (s2.navigator && s2.navigator.baseSeries[0] && (s2.navigator.baseSeries[0].xAxis.options.range = void 0), u2 = p2, x2 = c2);
              D && o2._offsetMin && d(u2) && (u2 += o2._offsetMin), o2._offsetMax && d(x2) && (x2 += o2._offsetMax), this.dropdown && (this.dropdown.selectedIndex = e3 + 1), r2 ? (r2.setExtremes(u2, x2, v(i3, true), void 0, { trigger: "rangeSelectorButton", rangeSelectorButton: o2 }), s2.setFixedRange(o2._range)) : (A = (m2 = M(s2.options.xAxis)[0]).range, m2.range = b2, S2 = m2.min, m2.min = y2, n(s2, "load", function() {
                s2.setFixedRange(o2._range), m2.range = A, m2.min = S2;
              })), g(this, "afterBtnClick");
            }
          }
          setSelected(t3) {
            this.selected = this.options.selected = t3;
          }
          init(t3) {
            let e3 = this, i3 = t3.options.rangeSelector, s2 = i3.buttons || e3.defaultButtons.slice(), o2 = i3.selected, r2 = function() {
              let t4 = e3.minInput, i4 = e3.maxInput;
              t4 && t4.blur && g(t4, "blur"), i4 && i4.blur && g(i4, "blur");
            };
            e3.chart = t3, e3.options = i3, e3.buttons = [], e3.buttonOptions = s2, this.eventsToUnbind = [], this.eventsToUnbind.push(n(t3.container, "mousedown", r2)), this.eventsToUnbind.push(n(t3, "resize", r2)), s2.forEach(e3.computeButtonRange), void 0 !== o2 && s2[o2] && this.clickButton(o2, false), this.eventsToUnbind.push(n(t3, "load", function() {
              t3.xAxis && t3.xAxis[0] && n(t3.xAxis[0], "setExtremes", function(i4) {
                f(this.max) && f(this.min) && this.max - this.min !== t3.fixedRange && "rangeSelectorButton" !== i4.trigger && "updatedData" !== i4.trigger && e3.forcedDataGrouping && !e3.frozenStates && this.setDataGrouping(false, false);
              });
            }));
          }
          updateButtonStates() {
            let t3 = this, e3 = this.chart, i3 = this.dropdown, s2 = e3.xAxis[0], o2 = Math.round(s2.max - s2.min), r2 = !s2.hasVisibleSeries, a2 = 24 * 36e5, n2 = e3.scroller && e3.scroller.getUnionExtremes() || s2, l2 = n2.dataMin, h2 = n2.dataMax, p2 = t3.getYTDExtremes(h2, l2, e3.time.useUTC), c2 = p2.min, u2 = p2.max, g2 = t3.selected, x2 = t3.options.allButtonsEnabled, m2 = t3.buttons, b2 = f(g2), v2 = false;
            t3.buttonOptions.forEach((e4, n3) => {
              let p3 = e4._range, f2 = e4.type, y2 = e4.count || 1, M2 = m2[n3], S2 = e4._offsetMax - e4._offsetMin, A = n3 === g2, k = p3 > h2 - l2, C = p3 < s2.minRange, D = 0, w = false, O = false, B = p3 === o2;
              if (A && k && (v2 = true), s2.isOrdinal && s2.ordinal?.positions && p3 && o2 < p3) {
                let t4 = s2.ordinal.positions;
                t4[t4.length - 1] - t4[0] > p3 && (B = true);
              } else
                ("month" === f2 || "year" === f2) && o2 + 36e5 >= { month: 28, year: 365 }[f2] * a2 * y2 - S2 && o2 - 36e5 <= { month: 31, year: 366 }[f2] * a2 * y2 + S2 ? B = true : "ytd" === f2 ? (B = u2 - c2 + S2 === o2, w = !A) : "all" === f2 && (B = s2.max - s2.min >= h2 - l2, O = !A && b2 && B);
              let E = !x2 && !(v2 && "all" === f2) && (k || C || O || r2), T = v2 && "all" === f2 || A && B || B && !b2 && !w || A && t3.frozenStates;
              E ? D = 3 : T && (b2 = true, D = 2), M2.state !== D && (M2.setState(D), i3 && (i3.options[n3 + 1].disabled = E, 2 === D && (i3.selectedIndex = n3 + 1)), 0 === D && g2 === n3 ? t3.setSelected() : (2 === D && !d(g2) || v2) && t3.setSelected(n3));
            });
          }
          computeButtonRange(t3) {
            let e3 = t3.type, i3 = t3.count || 1, s2 = { millisecond: 1, second: 1e3, minute: 6e4, hour: 36e5, day: 864e5, week: 6048e5 };
            s2[e3] ? t3._range = s2[e3] * i3 : ("month" === e3 || "year" === e3) && (t3._range = 24 * { month: 30, year: 365 }[e3] * 36e5 * i3), t3._offsetMin = v(t3.offsetMin, 0), t3._offsetMax = v(t3.offsetMax, 0), t3._range += t3._offsetMax - t3._offsetMin;
          }
          getInputValue(t3) {
            let e3 = "min" === t3 ? this.minInput : this.maxInput, i3 = this.chart.options.rangeSelector, s2 = this.chart.time;
            return e3 ? ("text" === e3.type && i3.inputDateParser || this.defaultInputDateParser)(e3.value, s2.useUTC, s2) : 0;
          }
          setInputValue(t3, e3) {
            let i3 = this.options, s2 = this.chart.time, o2 = "min" === t3 ? this.minInput : this.maxInput, r2 = "min" === t3 ? this.minDateBox : this.maxDateBox;
            if (o2) {
              let t4 = o2.getAttribute("data-hc-time"), a2 = d(t4) ? Number(t4) : void 0;
              if (d(e3)) {
                let t5 = a2;
                d(t5) && o2.setAttribute("data-hc-time-previous", t5), o2.setAttribute("data-hc-time", e3), a2 = e3;
              }
              o2.value = s2.dateFormat(this.inputTypeFormats[o2.type] || i3.inputEditDateFormat, a2), r2 && r2.attr({ text: s2.dateFormat(i3.inputDateFormat, a2) });
            }
          }
          setInputExtremes(t3, e3, i3) {
            let s2 = "min" === t3 ? this.minInput : this.maxInput;
            if (s2) {
              let t4 = this.inputTypeFormats[s2.type], o2 = this.chart.time;
              if (t4) {
                let r2 = o2.dateFormat(t4, e3);
                s2.min !== r2 && (s2.min = r2);
                let a2 = o2.dateFormat(t4, i3);
                s2.max !== a2 && (s2.max = a2);
              }
            }
          }
          showInput(t3) {
            let e3 = "min" === t3 ? this.minDateBox : this.maxDateBox, i3 = "min" === t3 ? this.minInput : this.maxInput;
            if (i3 && e3 && this.inputGroup) {
              let t4 = "text" === i3.type, { translateX: s2 = 0, translateY: o2 = 0 } = this.inputGroup, { x: r2 = 0, width: a2 = 0, height: n2 = 0 } = e3, { inputBoxWidth: l2 } = this.options;
              h(i3, { width: t4 ? a2 + (l2 ? -2 : 20) + "px" : "auto", height: n2 - 2 + "px", border: "2px solid silver" }), t4 && l2 ? h(i3, { left: s2 + r2 + "px", top: o2 + "px" }) : h(i3, { left: Math.min(Math.round(r2 + s2 - (i3.offsetWidth - a2) / 2), this.chart.chartWidth - i3.offsetWidth) + "px", top: o2 - (i3.offsetHeight - n2) / 2 + "px" });
            }
          }
          hideInput(t3) {
            let e3 = "min" === t3 ? this.minInput : this.maxInput;
            e3 && h(e3, { top: "-9999em", border: 0, width: "1px", height: "1px" });
          }
          defaultInputDateParser(t3, e3, s2) {
            let o2 = t3.split("/").join("-").split(" ").join("T");
            if (-1 === o2.indexOf("T") && (o2 += "T00:00"), e3)
              o2 += "Z";
            else {
              let t4;
              if (i2.isSafari && !((t4 = o2).length > 6 && (t4.lastIndexOf("-") === t4.length - 6 || t4.lastIndexOf("+") === t4.length - 6))) {
                let t5 = new Date(o2).getTimezoneOffset() / 60;
                o2 += t5 <= 0 ? `+${b(-t5)}:00` : `-${b(t5)}:00`;
              }
            }
            let r2 = Date.parse(o2);
            if (!f(r2)) {
              let e4 = t3.split("-");
              r2 = Date.UTC(y(e4[0]), y(e4[1]) - 1, y(e4[2]));
            }
            return s2 && e3 && f(r2) && (r2 += s2.getTimezoneOffset(r2)), r2;
          }
          drawInput(t3) {
            let { chart: e3, div: s2, inputGroup: o2 } = this, r2 = this, n2 = e3.renderer.style || {}, d2 = e3.renderer, p2 = e3.options.rangeSelector, c2 = a.lang, g2 = "min" === t3;
            function m2() {
              let { maxInput: i3, minInput: s3 } = r2, o3 = e3.xAxis[0], a2 = e3.scroller && e3.scroller.getUnionExtremes() || o3, n3 = a2.dataMin, l2 = a2.dataMax, h2 = r2.getInputValue(t3);
              h2 !== Number(M2.getAttribute("data-hc-time-previous")) && f(h2) && (M2.setAttribute("data-hc-time-previous", h2), g2 && i3 && f(n3) ? h2 > Number(i3.getAttribute("data-hc-time")) ? h2 = void 0 : h2 < n3 && (h2 = n3) : s3 && f(l2) && (h2 < Number(s3.getAttribute("data-hc-time")) ? h2 = void 0 : h2 > l2 && (h2 = l2)), void 0 !== h2 && o3.setExtremes(g2 ? h2 : o3.min, g2 ? o3.max : h2, void 0, void 0, { trigger: "rangeSelectorInput" }));
            }
            let b2 = c2[g2 ? "rangeSelectorFrom" : "rangeSelectorTo"] || "", v2 = d2.label(b2, 0).addClass("highcharts-range-label").attr({ padding: b2 ? 2 : 0, height: b2 ? p2.inputBoxHeight : 0 }).add(o2), y2 = d2.label("", 0).addClass("highcharts-range-input").attr({ padding: 2, width: p2.inputBoxWidth, height: p2.inputBoxHeight, "text-align": "center" }).on("click", function() {
              r2.showInput(t3), r2[t3 + "Input"].focus();
            });
            e3.styledMode || y2.attr({ stroke: p2.inputBoxBorderColor, "stroke-width": 1 }), y2.add(o2);
            let M2 = l("input", { name: t3, className: "highcharts-range-selector" }, void 0, s2);
            M2.setAttribute("type", function(t4) {
              if (-1 !== t4.indexOf("%L"))
                return "text";
              let e4 = ["a", "A", "d", "e", "w", "b", "B", "m", "o", "y", "Y"].some((e5) => -1 !== t4.indexOf("%" + e5)), i3 = ["H", "k", "I", "l", "M", "S"].some((e5) => -1 !== t4.indexOf("%" + e5));
              return e4 && i3 ? "datetime-local" : e4 ? "date" : i3 ? "time" : "text";
            }(p2.inputDateFormat || "%e %b %Y")), e3.styledMode || (v2.css(x(n2, p2.labelStyle)), y2.css(x({ color: "#333333" }, n2, p2.inputStyle)), h(M2, u({ position: "absolute", border: 0, boxShadow: "0 0 15px rgba(0,0,0,0.3)", width: "1px", height: "1px", padding: 0, textAlign: "center", fontSize: n2.fontSize, fontFamily: n2.fontFamily, top: "-9999em" }, p2.inputStyle))), M2.onfocus = () => {
              r2.showInput(t3);
            }, M2.onblur = () => {
              M2 === i2.doc.activeElement && m2(), r2.hideInput(t3), r2.setInputValue(t3), M2.blur();
            };
            let S2 = false;
            return M2.onchange = () => {
              S2 || (m2(), r2.hideInput(t3), M2.blur());
            }, M2.onkeypress = (t4) => {
              13 === t4.keyCode && m2();
            }, M2.onkeydown = (t4) => {
              S2 = true, (38 === t4.keyCode || 40 === t4.keyCode) && m2();
            }, M2.onkeyup = () => {
              S2 = false;
            }, { dateBox: y2, input: M2, label: v2 };
          }
          getPosition() {
            let t3 = this.chart, e3 = t3.options.rangeSelector, i3 = "top" === e3.verticalAlign ? t3.plotTop - t3.axisOffset[0] : 0;
            return { buttonTop: i3 + e3.buttonPosition.y, inputTop: i3 + e3.inputPosition.y - 10 };
          }
          getYTDExtremes(t3, e3, i3) {
            let s2 = this.chart.time, o2 = new s2.Date(t3), r2 = s2.get("FullYear", o2), a2 = i3 ? s2.Date.UTC(r2, 0, 1) : +new s2.Date(r2, 0, 1), n2 = o2.getTime();
            return { max: Math.min(t3 || n2, n2), min: Math.max(e3, a2) };
          }
          render(t3, e3) {
            let i3 = this.chart, s2 = i3.renderer, o2 = i3.container, r2 = i3.options, a2 = r2.rangeSelector, n2 = v(r2.chart.style && r2.chart.style.zIndex, 0) + 1, h2 = a2.inputEnabled, p2 = this.rendered;
            if (false !== a2.enabled) {
              if (!p2 && (this.group = s2.g("range-selector-group").attr({ zIndex: 7 }).add(), this.div = l("div", void 0, { position: "relative", height: 0, zIndex: n2 }), this.buttonOptions.length && this.renderButtons(), o2.parentNode && o2.parentNode.insertBefore(this.div, o2), h2)) {
                this.inputGroup = s2.g("input-group").add(this.group);
                let t4 = this.drawInput("min");
                this.minDateBox = t4.dateBox, this.minLabel = t4.label, this.minInput = t4.input;
                let e4 = this.drawInput("max");
                this.maxDateBox = e4.dateBox, this.maxLabel = e4.label, this.maxInput = e4.input;
              }
              if (h2) {
                this.setInputValue("min", t3), this.setInputValue("max", e3);
                let s3 = i3.scroller && i3.scroller.getUnionExtremes() || i3.xAxis[0] || {};
                if (d(s3.dataMin) && d(s3.dataMax)) {
                  let t4 = i3.xAxis[0].minRange || 0;
                  this.setInputExtremes("min", s3.dataMin, Math.min(s3.dataMax, this.getInputValue("max")) - t4), this.setInputExtremes("max", Math.max(s3.dataMin, this.getInputValue("min")) + t4, s3.dataMax);
                }
                if (this.inputGroup) {
                  let t4 = 0;
                  [this.minLabel, this.minDateBox, this.maxLabel, this.maxDateBox].forEach((e4) => {
                    if (e4) {
                      let { width: i4 } = e4.getBBox();
                      i4 && (e4.attr({ x: t4 }), t4 += i4 + a2.inputSpacing);
                    }
                  });
                }
              }
              this.alignElements(), this.rendered = true;
            }
          }
          renderButtons() {
            let { buttons: t3, chart: e3, options: s2 } = this, o2 = a.lang, r2 = e3.renderer, h2 = x(s2.buttonTheme), d2 = h2 && h2.states, p2 = h2.width || 28;
            delete h2.width, delete h2.states, this.buttonGroup = r2.g("range-selector-buttons").add(this.group);
            let c2 = this.dropdown = l("select", void 0, { position: "absolute", width: "1px", height: "1px", padding: 0, border: 0, top: "-9999em", cursor: "pointer", opacity: 1e-4 }, this.div);
            n(c2, "touchstart", () => {
              c2.style.fontSize = "16px";
            }), [[i2.isMS ? "mouseover" : "mouseenter"], [i2.isMS ? "mouseout" : "mouseleave"], ["change", "click"]].forEach(([e4, i3]) => {
              n(c2, e4, () => {
                let s3 = t3[this.currentButtonIndex()];
                s3 && g(s3.element, i3 || e4);
              });
            }), this.zoomText = r2.label(o2 && o2.rangeSelectorZoom || "", 0).attr({ padding: s2.buttonTheme.padding, height: s2.buttonTheme.height, paddingLeft: 0, paddingRight: 0 }).add(this.buttonGroup), this.chart.styledMode || (this.zoomText.css(s2.labelStyle), h2["stroke-width"] = v(h2["stroke-width"], 0)), l("option", { textContent: this.zoomText.textStr, disabled: true }, void 0, c2), this.buttonOptions.forEach((e4, i3) => {
              l("option", { textContent: e4.title || e4.text }, void 0, c2), t3[i3] = r2.button(e4.text, 0, 0, (t4) => {
                let s3;
                let o3 = e4.events && e4.events.click;
                o3 && (s3 = o3.call(e4, t4)), false !== s3 && this.clickButton(i3), this.isActive = true;
              }, h2, d2 && d2.hover, d2 && d2.select, d2 && d2.disabled).attr({ "text-align": "center", width: p2 }).add(this.buttonGroup), e4.title && t3[i3].attr("title", e4.title);
            });
          }
          alignElements() {
            let { buttonGroup: t3, buttons: e3, chart: i3, group: s2, inputGroup: o2, options: r2, zoomText: a2 } = this, n2 = i3.options, l2 = n2.exporting && false !== n2.exporting.enabled && n2.navigation && n2.navigation.buttonOptions, { buttonPosition: h2, inputPosition: d2, verticalAlign: p2 } = r2, c2 = (t4, e4) => l2 && this.titleCollision(i3) && "top" === p2 && "right" === e4.align && e4.y - t4.getBBox().height - 12 < (l2.y || 0) + (l2.height || 0) + i3.spacing[0] ? -40 : 0, u2 = i3.plotLeft;
            if (s2 && h2 && d2) {
              let n3 = h2.x - i3.spacing[3];
              if (t3) {
                if (this.positionButtons(), !this.initialButtonGroupWidth) {
                  let t4 = 0;
                  a2 && (t4 += a2.getBBox().width + 5), e3.forEach((i4, s3) => {
                    t4 += i4.width || 0, s3 !== e3.length - 1 && (t4 += r2.buttonSpacing);
                  }), this.initialButtonGroupWidth = t4;
                }
                u2 -= i3.spacing[3], this.updateButtonStates();
                let o3 = c2(t3, h2);
                this.alignButtonGroup(o3), s2.placed = t3.placed = i3.hasLoaded;
              }
              let l3 = 0;
              o2 && (l3 = c2(o2, d2), "left" === d2.align ? n3 = u2 : "right" === d2.align && (n3 = -Math.max(i3.axisOffset[1], -l3)), o2.align({ y: d2.y, width: o2.getBBox().width, align: d2.align, x: d2.x + n3 - 2 }, true, i3.spacingBox), o2.placed = i3.hasLoaded), this.handleCollision(l3), s2.align({ verticalAlign: p2 }, true, i3.spacingBox);
              let g2 = s2.alignAttr.translateY, f2 = s2.getBBox().height + 20, x2 = 0;
              if ("bottom" === p2) {
                let t4 = i3.legend && i3.legend.options;
                x2 = g2 - (f2 = f2 + (t4 && "bottom" === t4.verticalAlign && t4.enabled && !t4.floating ? i3.legend.legendHeight + v(t4.margin, 10) : 0) - 20) - (r2.floating ? 0 : r2.y) - (i3.titleOffset ? i3.titleOffset[2] : 0) - 10;
              }
              "top" === p2 ? (r2.floating && (x2 = 0), i3.titleOffset && i3.titleOffset[0] && (x2 = i3.titleOffset[0]), x2 += i3.margin[0] - i3.spacing[0] || 0) : "middle" === p2 && (d2.y === h2.y ? x2 = g2 : (d2.y || h2.y) && (d2.y < 0 || h2.y < 0 ? x2 -= Math.min(d2.y, h2.y) : x2 = g2 - f2)), s2.translate(r2.x, r2.y + Math.floor(x2));
              let { minInput: m2, maxInput: b2, dropdown: y2 } = this;
              r2.inputEnabled && m2 && b2 && (m2.style.marginTop = s2.translateY + "px", b2.style.marginTop = s2.translateY + "px"), y2 && (y2.style.marginTop = s2.translateY + "px");
            }
          }
          alignButtonGroup(t3, e3) {
            let { chart: i3, options: s2, buttonGroup: o2 } = this, { buttonPosition: r2 } = s2, a2 = i3.plotLeft - i3.spacing[3], n2 = r2.x - i3.spacing[3];
            "right" === r2.align ? n2 += t3 - a2 : "center" === r2.align && (n2 -= a2 / 2), o2 && o2.align({ y: r2.y, width: v(e3, this.initialButtonGroupWidth), align: r2.align, x: n2 }, true, i3.spacingBox);
          }
          positionButtons() {
            let { buttons: t3, chart: e3, options: i3, zoomText: s2 } = this, o2 = e3.hasLoaded ? "animate" : "attr", { buttonPosition: r2 } = i3, a2 = e3.plotLeft, n2 = a2;
            s2 && "hidden" !== s2.visibility && (s2[o2]({ x: v(a2 + r2.x, a2) }), n2 += r2.x + s2.getBBox().width + 5);
            for (let e4 = 0, s3 = this.buttonOptions.length; e4 < s3; ++e4)
              "hidden" !== t3[e4].visibility ? (t3[e4][o2]({ x: n2 }), n2 += (t3[e4].width || 0) + i3.buttonSpacing) : t3[e4][o2]({ x: a2 });
          }
          handleCollision(t3) {
            let { chart: e3, buttonGroup: i3, inputGroup: s2 } = this, { buttonPosition: o2, dropdown: r2, inputPosition: a2 } = this.options, n2 = () => {
              let t4 = 0;
              return this.buttons.forEach((e4) => {
                let i4 = e4.getBBox();
                i4.width > t4 && (t4 = i4.width);
              }), t4;
            }, l2 = (e4) => {
              if (s2 && i3) {
                let r3 = s2.alignAttr.translateX + s2.alignOptions.x - t3 + s2.getBBox().x + 2, n3 = s2.alignOptions.width, l3 = i3.alignAttr.translateX + i3.getBBox().x;
                return l3 + e4 > r3 && r3 + n3 > l3 && o2.y < a2.y + s2.getBBox().height;
              }
              return false;
            }, h2 = () => {
              s2 && i3 && s2.attr({ translateX: s2.alignAttr.translateX + (e3.axisOffset[1] >= -t3 ? 0 : -t3), translateY: s2.alignAttr.translateY + i3.getBBox().height + 10 });
            };
            if (i3) {
              if ("always" === r2) {
                this.collapseButtons(t3), l2(n2()) && h2();
                return;
              }
              "never" === r2 && this.expandButtons();
            }
            s2 && i3 ? a2.align === o2.align || l2(this.initialButtonGroupWidth + 20) ? "responsive" === r2 ? (this.collapseButtons(t3), l2(n2()) && h2()) : h2() : "responsive" === r2 && this.expandButtons() : i3 && "responsive" === r2 && (this.initialButtonGroupWidth > e3.plotWidth ? this.collapseButtons(t3) : this.expandButtons());
          }
          collapseButtons(t3) {
            let { buttons: e3, buttonOptions: i3, chart: s2, dropdown: o2, options: r2, zoomText: a2 } = this;
            if (true === this.isCollapsed)
              return;
            this.isCollapsed = true;
            let n2 = s2.userOptions.rangeSelector && s2.userOptions.rangeSelector.buttonTheme || {}, l2 = (t4) => ({ text: t4 ? `${t4} ▾` : "▾", width: "auto", paddingLeft: v(r2.buttonTheme.paddingLeft, n2.padding, 8), paddingRight: v(r2.buttonTheme.paddingRight, n2.padding, 8) });
            a2 && a2.hide();
            let h2 = false;
            i3.forEach((t4, i4) => {
              let s3 = e3[i4];
              2 !== s3.state ? s3.hide() : (s3.show(), s3.attr(l2(t4.text)), h2 = true);
            }), h2 || (o2 && (o2.selectedIndex = 0), e3[0].show(), e3[0].attr(l2(this.zoomText && this.zoomText.textStr)));
            let { align: d2 } = r2.buttonPosition;
            this.positionButtons(), ("right" === d2 || "center" === d2) && this.alignButtonGroup(t3, e3[this.currentButtonIndex()].getBBox().width), this.showDropdown();
          }
          expandButtons() {
            let { buttons: t3, buttonOptions: e3, options: i3, zoomText: s2 } = this;
            this.hideDropdown(), false !== this.isCollapsed && (this.isCollapsed = false, s2 && s2.show(), e3.forEach((e4, s3) => {
              let o2 = t3[s3];
              o2.show(), o2.attr({ text: e4.text, width: i3.buttonTheme.width || 28, paddingLeft: v(i3.buttonTheme.paddingLeft, "unset"), paddingRight: v(i3.buttonTheme.paddingRight, "unset") }), o2.state < 2 && o2.setState(0);
            }), this.positionButtons());
          }
          currentButtonIndex() {
            let { dropdown: t3 } = this;
            return t3 && t3.selectedIndex > 0 ? t3.selectedIndex - 1 : 0;
          }
          showDropdown() {
            let { buttonGroup: t3, buttons: e3, chart: i3, dropdown: s2 } = this;
            if (t3 && s2) {
              let { translateX: o2 = 0, translateY: r2 = 0 } = t3, a2 = e3[this.currentButtonIndex()].getBBox();
              h(s2, { left: i3.plotLeft + o2 + "px", top: r2 + 0.5 + "px", width: a2.width + "px", height: a2.height + "px" }), this.hasVisibleDropdown = true;
            }
          }
          hideDropdown() {
            let { dropdown: t3 } = this;
            t3 && (h(t3, { top: "-9999em", width: "1px", height: "1px" }), this.hasVisibleDropdown = false);
          }
          getHeight() {
            let t3 = this.options, e3 = this.group, i3 = t3.inputPosition, s2 = t3.buttonPosition, o2 = t3.y, r2 = s2.y, a2 = i3.y, n2 = 0;
            return t3.height ? t3.height : (this.alignElements(), n2 = e3 ? e3.getBBox(true).height + 13 + o2 : 0, (a2 < 0 && r2 < 0 || a2 > 0 && r2 > 0) && (n2 += Math.abs(Math.min(a2, r2))), n2);
          }
          titleCollision(t3) {
            return !(t3.options.title.text || t3.options.subtitle.text);
          }
          update(t3) {
            let e3 = this.chart;
            x(true, e3.options.rangeSelector, t3), this.destroy(), this.init(e3), this.render();
          }
          destroy() {
            let t3 = this, e3 = t3.minInput, i3 = t3.maxInput;
            t3.eventsToUnbind && (t3.eventsToUnbind.forEach((t4) => t4()), t3.eventsToUnbind = void 0), p(t3.buttons), e3 && (e3.onfocus = e3.onblur = e3.onchange = null), i3 && (i3.onfocus = i3.onblur = i3.onchange = null), m(t3, function(e4, i4) {
              e4 && "chart" !== i4 && (e4 instanceof o ? e4.destroy() : e4 instanceof window.HTMLElement && c(e4)), e4 !== S.prototype[i4] && (t3[i4] = null);
            }, this);
          }
        }
        return u(S.prototype, { defaultButtons: [{ type: "month", count: 1, text: "1m", title: "View 1 month" }, { type: "month", count: 3, text: "3m", title: "View 3 months" }, { type: "month", count: 6, text: "6m", title: "View 6 months" }, { type: "ytd", text: "YTD", title: "View year to date" }, { type: "year", count: 1, text: "1y", title: "View 1 year" }, { type: "all", text: "All", title: "View all" }], inputTypeFormats: { "datetime-local": "%Y-%m-%dT%H:%M:%S", date: "%Y-%m-%d", time: "%H:%M:%S" } }), S;
      }), i(e, "Core/Chart/StockChart.js", [e["Core/Chart/Chart.js"], e["Core/Templating.js"], e["Core/Defaults.js"], e["Stock/Navigator/NavigatorDefaults.js"], e["Stock/RangeSelector/RangeSelectorDefaults.js"], e["Stock/Scrollbar/ScrollbarDefaults.js"], e["Stock/Utilities/StockUtilities.js"], e["Core/Utilities.js"]], function(t2, e2, i2, s, o, r, a, n) {
        let { format: l } = e2, { getOptions: h } = i2, { setFixedRange: d } = a, { addEvent: p, clamp: c, defined: u, extend: g, find: f, isNumber: x, isString: m, merge: b, pick: v, splat: y } = n;
        function M(t3, e3, i3) {
          return "xAxis" === t3 ? { minPadding: 0, maxPadding: 0, overscroll: 0, ordinal: true } : "yAxis" === t3 ? { labels: { y: -2 }, opposite: i3.opposite ?? e3.opposite ?? true, showLastLabel: !!(e3.categories || "category" === e3.type), title: { text: i3.title?.text !== "Values" ? i3.title?.text : null } } : {};
        }
        function S(t3, e3) {
          if ("xAxis" === t3) {
            let t4 = v(e3.navigator && e3.navigator.enabled, s.enabled, true), i3 = { type: "datetime", categories: void 0 };
            return t4 && (i3.startOnTick = false, i3.endOnTick = false), i3;
          }
          return {};
        }
        class A extends t2 {
          init(t3, e3) {
            let i3 = h(), a2 = t3.xAxis, n2 = t3.yAxis, l2 = v(t3.navigator && t3.navigator.enabled, s.enabled, true);
            t3.xAxis = t3.yAxis = void 0;
            let d2 = b({ chart: { panning: { enabled: true, type: "x" }, zooming: { pinchType: "x", mouseWheel: { type: "x" } } }, navigator: { enabled: l2 }, scrollbar: { enabled: v(r.enabled, true) }, rangeSelector: { enabled: v(o.rangeSelector.enabled, true) }, title: { text: null }, tooltip: { split: v(i3.tooltip && i3.tooltip.split, true), crosshairs: true }, legend: { enabled: false } }, t3, { isStock: true });
            t3.xAxis = a2, t3.yAxis = n2, d2.xAxis = y(t3.xAxis || {}).map((e4) => b(M("xAxis", e4, i3.xAxis), e4, S("xAxis", t3))), d2.yAxis = y(t3.yAxis || {}).map((t4) => b(M("yAxis", t4, i3.yAxis), t4)), super.init(d2, e3);
          }
          createAxis(t3, e3) {
            return e3.axis = b(M(t3, e3.axis, h()[t3]), e3.axis, S(t3, this.userOptions)), super.createAxis(t3, e3);
          }
        }
        return p(t2, "update", function(t3) {
          let e3 = t3.options;
          "scrollbar" in e3 && this.navigator && (b(true, this.options.scrollbar, e3.scrollbar), this.navigator.update({}), delete e3.scrollbar);
        }), function(t3) {
          function e3(t4) {
            if (!this.crosshair || !this.crosshair.label || !this.crosshair.label.enabled || !this.cross || !x(this.min) || !x(this.max))
              return;
            let e4 = this.chart, i4 = this.logarithmic, s3 = this.crosshair.label, o3 = this.horiz, r3 = this.opposite, a3 = this.left, n3 = this.top, h3 = this.width, d2 = "inside" === this.options.tickPosition, p2 = false !== this.crosshair.snap, c2 = t4.e || this.cross && this.cross.e, u2 = t4.point, f2 = this.crossLabel, m2, b2, y2 = s3.format, M2 = "", S2, A2 = 0, k = this.min, C = this.max;
            i4 && (k = i4.lin2log(this.min), C = i4.lin2log(this.max));
            let D = o3 ? "center" : r3 ? "right" === this.labelAlign ? "right" : "left" : "left" === this.labelAlign ? "left" : "center";
            f2 || (f2 = this.crossLabel = e4.renderer.label("", 0, void 0, s3.shape || "callout").addClass("highcharts-crosshair-label highcharts-color-" + (u2 && u2.series ? u2.series.colorIndex : this.series[0] && this.series[0].colorIndex)).attr({ align: s3.align || D, padding: v(s3.padding, 8), r: v(s3.borderRadius, 3), zIndex: 2 }).add(this.labelGroup), e4.styledMode || f2.attr({ fill: s3.backgroundColor || u2 && u2.series && u2.series.color || "#666666", stroke: s3.borderColor || "", "stroke-width": s3.borderWidth || 0 }).css(g({ color: "#ffffff", fontWeight: "normal", fontSize: "0.7em", textAlign: "center" }, s3.style || {}))), o3 ? (m2 = p2 ? (u2.plotX || 0) + a3 : c2.chartX, b2 = n3 + (r3 ? 0 : this.height)) : (m2 = a3 + this.offset + (r3 ? h3 : 0), b2 = p2 ? (u2.plotY || 0) + n3 : c2.chartY), y2 || s3.formatter || (this.dateTime && (M2 = "%b %d, %Y"), y2 = "{value" + (M2 ? ":" + M2 : "") + "}");
            let w = p2 ? this.isXAxis ? u2.x : u2.y : this.toValue(o3 ? c2.chartX : c2.chartY), O = u2 && u2.series ? u2.series.isPointInside(u2) : x(w) && w > k && w < C, B = "";
            y2 ? B = l(y2, { value: w }, e4) : s3.formatter && x(w) && (B = s3.formatter.call(this, w)), f2.attr({ text: B, x: m2, y: b2, visibility: O ? "inherit" : "hidden" });
            let E = f2.getBBox();
            !x(f2.x) || o3 || r3 || (m2 = f2.x - E.width / 2), x(f2.y) && (o3 ? (d2 && !r3 || !d2 && r3) && (b2 = f2.y - E.height) : b2 = f2.y - E.height / 2), S2 = o3 ? { left: a3 - E.x, right: a3 + this.width - E.x } : { left: "left" === this.labelAlign ? a3 : 0, right: "right" === this.labelAlign ? a3 + this.width : e4.chartWidth };
            let T = f2.translateX || 0;
            T < S2.left && (A2 = S2.left - T), T + E.width >= S2.right && (A2 = -(T + E.width - S2.right)), f2.attr({ x: m2 + A2, y: b2, anchorX: o3 ? m2 : this.opposite ? 0 : e4.chartWidth, anchorY: o3 ? this.opposite ? e4.chartHeight : 0 : b2 + E.height / 2 });
          }
          function i3() {
            this.crossLabel && (this.crossLabel = this.crossLabel.hide());
          }
          function s2(t4) {
            let e4 = this.chart, i4 = this.options, s3 = e4._labelPanes = e4._labelPanes || {}, o3 = i4.labels;
            if (e4.options.isStock && "yAxis" === this.coll) {
              let e5 = i4.top + "," + i4.height;
              !s3[e5] && o3.enabled && (15 === o3.distance && 1 === this.side && (o3.distance = 0), void 0 === o3.align && (o3.align = "right"), s3[e5] = this, t4.align = "right", t4.preventDefault());
            }
          }
          function o2() {
            let t4 = this.chart, e4 = this.options && this.options.top + "," + this.options.height;
            e4 && t4._labelPanes && t4._labelPanes[e4] === this && delete t4._labelPanes[e4];
          }
          function r2(t4) {
            let e4 = this, i4 = e4.isLinked && !e4.series && e4.linkedParent ? e4.linkedParent.series : e4.series, s3 = e4.chart, o3 = s3.renderer, r3 = e4.left, a3 = e4.top, n3 = [], l2 = t4.translatedValue, h3 = t4.value, d2 = t4.force, p2, g2, b2, y2, M2 = [], S2, A2;
            if (s3.options.isStock && false !== t4.acrossPanes && "xAxis" === e4.coll || "yAxis" === e4.coll) {
              for (let o4 of (t4.preventDefault(), M2 = ((t5) => {
                let o5 = "xAxis" === t5 ? "yAxis" : "xAxis", r4 = e4.options[o5];
                return x(r4) ? [s3[o5][r4]] : m(r4) ? [s3.get(r4)] : i4.map((t6) => t6[o5]);
              })(e4.coll), e4.isXAxis ? s3.yAxis : s3.xAxis))
                if (!u(o4.options.id) || -1 === o4.options.id.indexOf("navigator")) {
                  let t5 = o4.isXAxis ? "yAxis" : "xAxis";
                  e4 === (u(o4.options[t5]) ? s3[t5][o4.options[t5]] : s3[t5][0]) && M2.push(o4);
                }
              for (let t5 of (S2 = M2.length ? [] : [e4.isXAxis ? s3.yAxis[0] : s3.xAxis[0]], M2))
                -1 !== S2.indexOf(t5) || f(S2, (e5) => e5.pos === t5.pos && e5.len === t5.len) || S2.push(t5);
              if (x(A2 = v(l2, e4.translate(h3 || 0, void 0, void 0, t4.old)))) {
                if (e4.horiz)
                  for (let t5 of S2) {
                    let i5;
                    y2 = (g2 = t5.pos) + t5.len, p2 = b2 = Math.round(A2 + e4.transB), "pass" !== d2 && (p2 < r3 || p2 > r3 + e4.width) && (d2 ? p2 = b2 = c(p2, r3, r3 + e4.width) : i5 = true), i5 || n3.push(["M", p2, g2], ["L", b2, y2]);
                  }
                else
                  for (let t5 of S2) {
                    let i5;
                    b2 = (p2 = t5.pos) + t5.len, g2 = y2 = Math.round(a3 + e4.height - A2), "pass" !== d2 && (g2 < a3 || g2 > a3 + e4.height) && (d2 ? g2 = y2 = c(g2, a3, a3 + e4.height) : i5 = true), i5 || n3.push(["M", p2, g2], ["L", b2, y2]);
                  }
              }
              t4.path = n3.length > 0 ? o3.crispPolyLine(n3, t4.lineWidth || 1) : void 0;
            }
          }
          function a2(t4) {
            if (this.chart.options.isStock) {
              let e4;
              this.is("column") || this.is("columnrange") ? e4 = { borderWidth: 0, shadow: false } : this.is("scatter") || this.is("sma") || (e4 = { marker: { enabled: false, radius: 2 } }), e4 && (t4.plotOptions[this.type] = b(t4.plotOptions[this.type], e4));
            }
          }
          function n2() {
            let t4 = this.chart, e4 = this.options.dataGrouping;
            return false !== this.allowDG && e4 && v(e4.enabled, t4.options.isStock);
          }
          function h2(t4, e4) {
            for (let i4 = 0; i4 < t4.length; i4 += 2) {
              let s3 = t4[i4], o3 = t4[i4 + 1];
              s3[1] === o3[1] && (s3[1] = o3[1] = Math.round(s3[1]) - e4 % 2 / 2), s3[2] === o3[2] && (s3[2] = o3[2] = Math.round(s3[2]) + e4 % 2 / 2);
            }
            return t4;
          }
          t3.compose = function(t4, l2, c2, u2) {
            let g2 = c2.prototype;
            g2.forceCropping || (p(l2, "afterDrawCrosshair", e3), p(l2, "afterHideCrosshair", i3), p(l2, "autoLabelAlign", s2), p(l2, "destroy", o2), p(l2, "getPlotLinePath", r2), t4.prototype.setFixedRange = d, g2.forceCropping = n2, p(c2, "setOptions", a2), u2.prototype.crispPolyLine = h2);
          }, t3.stockChart = function(e4, i4, s3) {
            return new t3(e4, i4, s3);
          };
        }(A || (A = {})), A;
      }), i(e, "Series/HLC/HLCPoint.js", [e["Core/Series/SeriesRegistry.js"]], function(t2) {
        let { column: { prototype: { pointClass: e2 } } } = t2.seriesTypes;
        return class extends e2 {
        };
      }), i(e, "Series/HLC/HLCSeriesDefaults.js", [], function() {
        return { lineWidth: 1, tooltip: { pointFormat: '<span style="color:{point.color}">●</span> <b> {series.name}</b><br/>High: {point.high}<br/>Low: {point.low}<br/>Close: {point.close}<br/>' }, threshold: null, states: { hover: { lineWidth: 3 } }, stickyTracking: true };
      }), i(e, "Series/HLC/HLCSeries.js", [e["Series/HLC/HLCPoint.js"], e["Series/HLC/HLCSeriesDefaults.js"], e["Core/Series/SeriesRegistry.js"], e["Core/Utilities.js"]], function(t2, e2, i2, s) {
        let { column: o } = i2.seriesTypes, { extend: r, merge: a } = s;
        class n extends o {
          extendStem(t3, e3, i3) {
            let s2 = t3[0], o2 = t3[1];
            "number" == typeof s2[2] && (s2[2] = Math.max(i3 + e3, s2[2])), "number" == typeof o2[2] && (o2[2] = Math.min(i3 - e3, o2[2]));
          }
          getPointPath(t3, e3) {
            let i3 = e3.strokeWidth(), s2 = t3.series, o2 = i3 % 2 / 2, r2 = Math.round(t3.plotX) - o2, a2 = Math.round(t3.shapeArgs.width / 2), n2 = t3.plotClose, l = [["M", r2, Math.round(t3.yBottom)], ["L", r2, Math.round(t3.plotHigh)]];
            return null !== t3.close && (n2 = Math.round(t3.plotClose) + o2, l.push(["M", r2, n2], ["L", r2 + a2, n2]), s2.extendStem(l, i3 / 2, n2)), l;
          }
          drawSinglePoint(t3) {
            let e3 = t3.series, i3 = e3.chart, s2, o2 = t3.graphic;
            void 0 !== t3.plotY && (o2 || (t3.graphic = o2 = i3.renderer.path().add(e3.group)), i3.styledMode || o2.attr(e3.pointAttribs(t3, t3.selected && "select")), s2 = e3.getPointPath(t3, o2), o2[o2 ? "animate" : "attr"]({ d: s2 }).addClass(t3.getClassName(), true));
          }
          drawPoints() {
            this.points.forEach(this.drawSinglePoint);
          }
          init() {
            super.init.apply(this, arguments), this.options.stacking = void 0;
          }
          pointAttribs(t3, e3) {
            let i3 = super.pointAttribs.call(this, t3, e3);
            return delete i3.fill, i3;
          }
          toYData(t3) {
            return [t3.high, t3.low, t3.close];
          }
          translate() {
            let t3 = this, e3 = t3.yAxis, i3 = this.pointArrayMap && this.pointArrayMap.slice() || [], s2 = i3.map((t4) => `plot${t4.charAt(0).toUpperCase() + t4.slice(1)}`);
            s2.push("yBottom"), i3.push("low"), super.translate.apply(t3), t3.points.forEach(function(o2) {
              i3.forEach(function(i4, r2) {
                let a2 = o2[i4];
                null !== a2 && (t3.dataModify && (a2 = t3.dataModify.modifyValue(a2)), o2[s2[r2]] = e3.toPixels(a2, true));
              }), o2.tooltipPos[1] = o2.plotHigh + e3.pos - t3.chart.plotTop;
            });
          }
        }
        return n.defaultOptions = a(o.defaultOptions, e2), r(n.prototype, { pointClass: t2, animate: null, directTouch: false, pointArrayMap: ["high", "low", "close"], pointAttrToOptions: { stroke: "color", "stroke-width": "lineWidth" }, pointValKey: "close" }), i2.registerSeriesType("hlc", n), n;
      }), i(e, "Series/OHLC/OHLCPoint.js", [e["Core/Series/SeriesRegistry.js"]], function(t2) {
        let { seriesTypes: { hlc: e2 } } = t2;
        class i2 extends e2.prototype.pointClass {
          getClassName() {
            return super.getClassName.call(this) + (this.open < this.close ? " highcharts-point-up" : " highcharts-point-down");
          }
          resolveUpColor() {
            this.open < this.close && !this.options.color && this.series.options.upColor && (this.color = this.series.options.upColor);
          }
          resolveColor() {
            super.resolveColor(), this.series.is("heikinashi") || this.resolveUpColor();
          }
          getZone() {
            let t3 = super.getZone();
            return this.resolveUpColor(), t3;
          }
          applyOptions() {
            return super.applyOptions.apply(this, arguments), this.resolveColor && this.resolveColor(), this;
          }
        }
        return i2;
      }), i(e, "Series/OHLC/OHLCSeriesDefaults.js", [], function() {
        return { tooltip: { pointFormat: '<span style="color:{point.color}">●</span> <b> {series.name}</b><br/>Open: {point.open}<br/>High: {point.high}<br/>Low: {point.low}<br/>Close: {point.close}<br/>' } };
      }), i(e, "Series/OHLC/OHLCSeries.js", [e["Core/Globals.js"], e["Series/OHLC/OHLCPoint.js"], e["Series/OHLC/OHLCSeriesDefaults.js"], e["Core/Series/SeriesRegistry.js"], e["Core/Utilities.js"]], function(t2, e2, i2, s, o) {
        let { composed: r } = t2, { hlc: a } = s.seriesTypes, { addEvent: n, extend: l, merge: h, pushUnique: d } = o;
        function p(t3) {
          let e3 = t3.options, i3 = e3.dataGrouping;
          i3 && e3.useOhlcData && "highcharts-navigator-series" !== e3.id && (i3.approximation = "ohlc");
        }
        function c(t3) {
          let e3 = t3.options;
          e3.useOhlcData && "highcharts-navigator-series" !== e3.id && l(this, { pointValKey: u.prototype.pointValKey, pointArrayMap: u.prototype.pointArrayMap, toYData: u.prototype.toYData });
        }
        class u extends a {
          static compose(t3, ...e3) {
            d(r, "OHLCSeries") && (n(t3, "afterSetOptions", p), n(t3, "init", c));
          }
          getPointPath(t3, e3) {
            let i3 = super.getPointPath(t3, e3), s2 = e3.strokeWidth(), o2 = s2 % 2 / 2, r2 = Math.round(t3.plotX) - o2, a2 = Math.round(t3.shapeArgs.width / 2), n2 = t3.plotOpen;
            return null !== t3.open && (n2 = Math.round(t3.plotOpen) + o2, i3.push(["M", r2, n2], ["L", r2 - a2, n2]), super.extendStem(i3, s2 / 2, n2)), i3;
          }
          pointAttribs(t3, e3) {
            let i3 = super.pointAttribs.call(this, t3, e3), s2 = this.options;
            return delete i3.fill, !t3.options.color && s2.upColor && t3.open < t3.close && (i3.stroke = s2.upColor), i3;
          }
          toYData(t3) {
            return [t3.open, t3.high, t3.low, t3.close];
          }
        }
        return u.defaultOptions = h(a.defaultOptions, i2), l(u.prototype, { pointClass: e2, pointArrayMap: ["open", "high", "low", "close"] }), s.registerSeriesType("ohlc", u), u;
      }), i(e, "Series/Candlestick/CandlestickSeriesDefaults.js", [], function() {
        return { states: { hover: { lineWidth: 2 } }, threshold: null, lineColor: "#000000", lineWidth: 1, upColor: "#ffffff", stickyTracking: true };
      }), i(e, "Series/Candlestick/CandlestickSeries.js", [e["Series/Candlestick/CandlestickSeriesDefaults.js"], e["Core/Defaults.js"], e["Core/Series/SeriesRegistry.js"], e["Core/Utilities.js"]], function(t2, e2, i2, s) {
        let { defaultOptions: o } = e2, { column: r, ohlc: a } = i2.seriesTypes, { merge: n } = s;
        class l extends a {
          pointAttribs(t3, e3) {
            let i3 = r.prototype.pointAttribs.call(this, t3, e3), s2 = this.options, o2 = t3.open < t3.close, a2 = s2.lineColor || this.color, n2 = t3.color || this.color;
            if (i3["stroke-width"] = s2.lineWidth, i3.fill = t3.options.color || o2 && s2.upColor || n2, i3.stroke = t3.options.lineColor || o2 && s2.upLineColor || a2, e3) {
              let t4 = s2.states[e3];
              i3.fill = t4.color || i3.fill, i3.stroke = t4.lineColor || i3.stroke, i3["stroke-width"] = t4.lineWidth || i3["stroke-width"];
            }
            return i3;
          }
          drawPoints() {
            let t3 = this.points, e3 = this.chart, i3 = this.yAxis.reversed;
            for (let s2 of t3) {
              let t4 = s2.graphic, o2, r2, a2, n2, l2, h, d, p, c, u, g = !t4;
              void 0 !== s2.plotY && (t4 || (s2.graphic = t4 = e3.renderer.path().add(this.group)), this.chart.styledMode || t4.attr(this.pointAttribs(s2, s2.selected && "select")).shadow(this.options.shadow), d = t4.strokeWidth() % 2 / 2, p = Math.round(s2.plotX) - d, a2 = Math.min(o2 = s2.plotOpen, r2 = s2.plotClose), n2 = Math.max(o2, r2), u = Math.round(s2.shapeArgs.width / 2), l2 = i3 ? n2 !== s2.yBottom : Math.round(a2) !== Math.round(s2.plotHigh), h = i3 ? Math.round(a2) !== Math.round(s2.plotHigh) : n2 !== s2.yBottom, a2 = Math.round(a2) + d, n2 = Math.round(n2) + d, (c = []).push(["M", p - u, n2], ["L", p - u, a2], ["L", p + u, a2], ["L", p + u, n2], ["Z"], ["M", p, a2], ["L", p, l2 ? Math.round(i3 ? s2.yBottom : s2.plotHigh) : a2], ["M", p, n2], ["L", p, h ? Math.round(i3 ? s2.plotHigh : s2.yBottom) : n2]), t4[g ? "attr" : "animate"]({ d: c }).addClass(s2.getClassName(), true));
            }
          }
        }
        return l.defaultOptions = n(a.defaultOptions, o.plotOptions, { tooltip: a.defaultOptions.tooltip }, t2), i2.registerSeriesType("candlestick", l), l;
      }), i(e, "Series/Flags/FlagsPoint.js", [e["Core/Series/SeriesRegistry.js"], e["Core/Utilities.js"]], function(t2, e2) {
        let { column: { prototype: { pointClass: i2 } } } = t2.seriesTypes, { isNumber: s } = e2;
        return class extends i2 {
          constructor() {
            super(...arguments), this.ttBelow = false;
          }
          isValid() {
            return s(this.y) || void 0 === this.y;
          }
          hasNewShapeType() {
            let t3 = this.options.shape || this.series.options.shape;
            return this.graphic && t3 && t3 !== this.graphic.symbolKey;
          }
        };
      }), i(e, "Series/Flags/FlagsSeriesDefaults.js", [], function() {
        return { pointRange: 0, allowOverlapX: false, shape: "flag", stackDistance: 12, textAlign: "center", tooltip: { pointFormat: "{point.text}" }, threshold: null, y: -30, fillColor: "#ffffff", lineWidth: 1, states: { hover: { lineColor: "#000000", fillColor: "#ccd3ff" } }, style: { fontSize: "0.7em", fontWeight: "bold" } };
      }), i(e, "Series/Flags/FlagsSymbols.js", [e["Core/Renderer/RendererRegistry.js"]], function(t2) {
        var e2;
        return function(e3) {
          let i2 = [];
          function s(t3, e4, i3, s2, o2) {
            let r = o2 && o2.anchorX || t3, a = o2 && o2.anchorY || e4, n = this.circle(r - 1, a - 1, 2, 2);
            return n.push(["M", r, a], ["L", t3, e4 + s2], ["L", t3, e4], ["L", t3 + i3, e4], ["L", t3 + i3, e4 + s2], ["L", t3, e4 + s2], ["Z"]), n;
          }
          function o(t3, e4) {
            t3[e4 + "pin"] = function(i3, s2, o2, r, a) {
              let n;
              let l = a && a.anchorX, h = a && a.anchorY;
              if ("circle" === e4 && r > o2 && (i3 -= Math.round((r - o2) / 2), o2 = r), n = t3[e4](i3, s2, o2, r), l && h) {
                let a2 = l;
                if ("circle" === e4)
                  a2 = i3 + o2 / 2;
                else {
                  let t4 = n[0], e5 = n[1];
                  "M" === t4[0] && "L" === e5[0] && (a2 = (t4[1] + e5[1]) / 2);
                }
                let d = s2 > h ? s2 : s2 + r;
                n.push(["M", a2, d], ["L", l, h]), n = n.concat(t3.circle(l - 1, h - 1, 2, 2));
              }
              return n;
            };
          }
          e3.compose = function(e4) {
            if (-1 === i2.indexOf(e4)) {
              i2.push(e4);
              let t3 = e4.prototype.symbols;
              t3.flag = s, o(t3, "circle"), o(t3, "square");
            }
            let r = t2.getRendererType();
            i2.indexOf(r) && i2.push(r);
          };
        }(e2 || (e2 = {})), e2;
      }), i(e, "Series/OnSeriesComposition.js", [e["Series/Column/ColumnSeries.js"], e["Core/Globals.js"], e["Core/Series/Series.js"], e["Core/Utilities.js"]], function(t2, e2, i2, s) {
        var o;
        let { composed: r } = e2, { prototype: a } = t2, { prototype: n } = i2, { defined: l, pushUnique: h, stableSort: d } = s;
        return function(t3) {
          function e3(t4) {
            return n.getPlotBox.call(this.options.onSeries && this.chart.get(this.options.onSeries) || this, t4);
          }
          function i3() {
            a.translate.apply(this);
            let t4 = this, e4 = t4.options, i4 = t4.chart, s2 = t4.points, o2 = e4.onSeries, r2 = o2 && i4.get(o2), n2 = r2 && r2.options.step, h2 = r2 && r2.points, p = i4.inverted, c = t4.xAxis, u = t4.yAxis, g = s2.length - 1, f, x, m = e4.onKey || "y", b = h2 && h2.length, v = 0, y, M, S, A, k;
            if (r2 && r2.visible && b) {
              for (v = (r2.pointXOffset || 0) + (r2.barW || 0) / 2, A = r2.currentDataGrouping, M = h2[b - 1].x + (A ? A.totalRange : 0), d(s2, (t5, e5) => t5.x - e5.x), m = "plot" + m[0].toUpperCase() + m.substr(1); b-- && s2[g]; )
                if (y = h2[b], (f = s2[g]).y = y.y, y.x <= f.x && void 0 !== y[m]) {
                  if (f.x <= M && (f.plotY = y[m], y.x < f.x && !n2 && (S = h2[b + 1]) && void 0 !== S[m])) {
                    if (l(f.plotX) && r2.is("spline")) {
                      let t5 = [y.plotX || 0, y.plotY || 0], e5 = [S.plotX || 0, S.plotY || 0], i5 = y.controlPoints?.high || t5, s3 = S.controlPoints?.low || e5, o3 = (o4, r4) => Math.pow(1 - o4, 3) * t5[r4] + 3 * (1 - o4) * (1 - o4) * o4 * i5[r4] + 3 * (1 - o4) * o4 * o4 * s3[r4] + o4 * o4 * o4 * e5[r4], r3 = 0, a2 = 1, n3;
                      for (let t6 = 0; t6 < 100; t6++) {
                        let t7 = (r3 + a2) / 2, e6 = o3(t7, 0);
                        if (null === e6)
                          break;
                        if (0.25 > Math.abs(e6 - f.plotX)) {
                          n3 = t7;
                          break;
                        }
                        e6 < f.plotX ? r3 = t7 : a2 = t7;
                      }
                      l(n3) && (f.plotY = o3(n3, 1), f.y = u.toValue(f.plotY, true));
                    } else
                      k = (f.x - y.x) / (S.x - y.x), f.plotY += k * (S[m] - y[m]), f.y += k * (S.y - y.y);
                  }
                  if (g--, b++, g < 0)
                    break;
                }
            }
            s2.forEach((e5, i5) => {
              let o3;
              e5.plotX += v, (void 0 === e5.plotY || p) && (e5.plotX >= 0 && e5.plotX <= c.len ? p ? (e5.plotY = c.translate(e5.x, 0, 1, 0, 1), e5.plotX = l(e5.y) ? u.translate(e5.y, 0, 0, 0, 1) : 0) : e5.plotY = (c.opposite ? 0 : t4.yAxis.len) + c.offset : e5.shapeArgs = {}), (x = s2[i5 - 1]) && x.plotX === e5.plotX && (void 0 === x.stackIndex && (x.stackIndex = 0), o3 = x.stackIndex + 1), e5.stackIndex = o3;
            }), this.onSeries = r2;
          }
          t3.compose = function(t4) {
            if (h(r, "OnSeries")) {
              let s2 = t4.prototype;
              s2.getPlotBox = e3, s2.translate = i3;
            }
            return t4;
          }, t3.getPlotBox = e3, t3.translate = i3;
        }(o || (o = {})), o;
      }), i(e, "Series/Flags/FlagsSeries.js", [e["Series/Flags/FlagsPoint.js"], e["Series/Flags/FlagsSeriesDefaults.js"], e["Series/Flags/FlagsSymbols.js"], e["Core/Globals.js"], e["Series/OnSeriesComposition.js"], e["Core/Renderer/RendererUtilities.js"], e["Core/Series/SeriesRegistry.js"], e["Core/Renderer/SVG/SVGElement.js"], e["Core/Utilities.js"]], function(t2, e2, i2, s, o, r, a, n, l) {
        let { noop: h } = s, { distribute: d } = r, { series: p, seriesTypes: { column: c } } = a, { addEvent: u, defined: g, extend: f, merge: x, objectEach: m, wrap: b } = l;
        class v extends c {
          animate(t3) {
            t3 && this.setClip();
          }
          drawPoints() {
            let t3, e3, i3, s2, o2, r2, a2, l2, h2, p2, c2;
            let u2 = this.points, f2 = this.chart, v2 = f2.renderer, y = f2.inverted, M = this.options, S = M.y, A = this.yAxis, k = {}, C = [];
            for (s2 = u2.length; s2--; )
              o2 = u2[s2], p2 = (y ? o2.plotY : o2.plotX) > this.xAxis.len, t3 = o2.plotX, a2 = o2.stackIndex, i3 = o2.options.shape || M.shape, void 0 !== (e3 = o2.plotY) && (e3 = o2.plotY + S - (void 0 !== a2 && a2 * M.stackDistance)), o2.anchorX = a2 ? void 0 : o2.plotX, l2 = a2 ? void 0 : o2.plotY, c2 = "flag" !== i3, r2 = o2.graphic, void 0 !== e3 && t3 >= 0 && !p2 ? (r2 && o2.hasNewShapeType() && (r2 = r2.destroy()), r2 || (r2 = o2.graphic = v2.label("", null, null, i3, null, null, M.useHTML).addClass("highcharts-point").add(this.markerGroup), o2.graphic.div && (o2.graphic.div.point = o2), r2.isNew = true), r2.attr({ align: c2 ? "center" : "left", width: M.width, height: M.height, "text-align": M.textAlign }), f2.styledMode || r2.attr(this.pointAttribs(o2)).css(x(M.style, o2.style)).shadow(M.shadow), t3 > 0 && (t3 -= r2.strokeWidth() % 2), h2 = { y: e3, anchorY: l2 }, M.allowOverlapX && (h2.x = t3, h2.anchorX = o2.anchorX), r2.attr({ text: o2.options.title || M.title || "A" })[r2.isNew ? "attr" : "animate"](h2), M.allowOverlapX || (k[o2.plotX] ? k[o2.plotX].size = Math.max(k[o2.plotX].size, r2.width || 0) : k[o2.plotX] = { align: c2 ? 0.5 : 0, size: r2.width || 0, target: t3, anchorX: t3 }), o2.tooltipPos = [t3, e3 + A.pos - f2.plotTop]) : r2 && (o2.graphic = r2.destroy());
            if (!M.allowOverlapX) {
              let t4 = 100;
              for (let e4 of (m(k, function(e5) {
                e5.plotX = e5.anchorX, C.push(e5), t4 = Math.max(e5.size, t4);
              }), d(C, y ? A.len : this.xAxis.len, t4), u2)) {
                let t5 = e4.plotX, i4 = e4.graphic, s3 = i4 && k[t5];
                s3 && i4 && (g(s3.pos) ? i4[i4.isNew ? "attr" : "animate"]({ x: s3.pos + (s3.align || 0) * s3.size, anchorX: e4.anchorX }).show().isNew = false : i4.hide().isNew = true);
              }
            }
            M.useHTML && this.markerGroup && b(this.markerGroup, "on", function(t4) {
              return n.prototype.on.apply(t4.apply(this, [].slice.call(arguments, 1)), [].slice.call(arguments, 1));
            });
          }
          drawTracker() {
            let t3 = this.points;
            for (let e3 of (super.drawTracker(), t3)) {
              let i3 = e3.graphic;
              i3 && (e3.unbindMouseOver && e3.unbindMouseOver(), e3.unbindMouseOver = u(i3.element, "mouseover", function() {
                for (let s2 of (e3.stackIndex > 0 && !e3.raised && (e3._y = i3.y, i3.attr({ y: e3._y - 8 }), e3.raised = true), t3))
                  s2 !== e3 && s2.raised && s2.graphic && (s2.graphic.attr({ y: s2._y }), s2.raised = false);
              }));
            }
          }
          pointAttribs(t3, e3) {
            let i3 = this.options, s2 = t3 && t3.color || this.color, o2 = i3.lineColor, r2 = t3 && t3.lineWidth, a2 = t3 && t3.fillColor || i3.fillColor;
            return e3 && (a2 = i3.states[e3].fillColor, o2 = i3.states[e3].lineColor, r2 = i3.states[e3].lineWidth), { fill: a2 || s2, stroke: o2 || s2, "stroke-width": r2 || i3.lineWidth || 0 };
          }
          setClip() {
            p.prototype.setClip.apply(this, arguments), false !== this.options.clip && this.sharedClipKey && this.markerGroup && this.markerGroup.clip(this.chart.sharedClips[this.sharedClipKey]);
          }
        }
        return v.compose = i2.compose, v.defaultOptions = x(c.defaultOptions, e2), o.compose(v), f(v.prototype, { allowDG: false, forceCrop: true, invertible: false, noSharedTooltip: true, pointClass: t2, sorted: false, takeOrdinalPosition: false, trackerGroups: ["markerGroup"], buildKDTree: h, init: p.prototype.init }), a.registerSeriesType("flags", v), v;
      }), i(e, "Core/Axis/BrokenAxis.js", [e["Core/Axis/Stacking/StackItem.js"], e["Core/Utilities.js"]], function(t2, e2) {
        var i2;
        let { addEvent: s, find: o, fireEvent: r, isArray: a, isNumber: n, pick: l } = e2;
        return function(e3) {
          function i3() {
            void 0 !== this.brokenAxis && this.brokenAxis.setBreaks(this.options.breaks, false);
          }
          function h() {
            this.brokenAxis?.hasBreaks && (this.options.ordinal = false);
          }
          function d() {
            let t3 = this.brokenAxis;
            if (t3?.hasBreaks) {
              let e4 = this.tickPositions, i4 = this.tickPositions.info, s2 = [];
              for (let i5 = 0; i5 < e4.length; i5++)
                t3.isInAnyBreak(e4[i5]) || s2.push(e4[i5]);
              this.tickPositions = s2, this.tickPositions.info = i4;
            }
          }
          function p() {
            this.brokenAxis || (this.brokenAxis = new x(this));
          }
          function c() {
            let { isDirty: t3, options: { connectNulls: e4 }, points: i4, xAxis: s2, yAxis: o2 } = this;
            if (t3) {
              let t4 = i4.length;
              for (; t4--; ) {
                let r2 = i4[t4], a2 = !(null === r2.y && false === e4) && (s2?.brokenAxis?.isInAnyBreak(r2.x, true) || o2?.brokenAxis?.isInAnyBreak(r2.y, true));
                r2.visible = !a2 && false !== r2.options.visible;
              }
            }
          }
          function u() {
            this.drawBreaks(this.xAxis, ["x"]), this.drawBreaks(this.yAxis, l(this.pointArrayMap, ["y"]));
          }
          function g(t3, e4) {
            let i4, s2, o2;
            let a2 = this, h2 = a2.points;
            if (t3?.brokenAxis?.hasBreaks) {
              let d2 = t3.brokenAxis;
              e4.forEach(function(e5) {
                i4 = d2?.breakArray || [], s2 = t3.isXAxis ? t3.min : l(a2.options.threshold, t3.min);
                let p2 = t3?.options?.breaks?.filter(function(t4) {
                  let e6 = true;
                  for (let s3 = 0; s3 < i4.length; s3++) {
                    let o3 = i4[s3];
                    if (o3.from === t4.from && o3.to === t4.to) {
                      e6 = false;
                      break;
                    }
                  }
                  return e6;
                });
                h2.forEach(function(a3) {
                  o2 = l(a3["stack" + e5.toUpperCase()], a3[e5]), i4.forEach(function(e6) {
                    if (n(s2) && n(o2)) {
                      let i5 = "";
                      s2 < e6.from && o2 > e6.to || s2 > e6.from && o2 < e6.from ? i5 = "pointBreak" : (s2 < e6.from && o2 > e6.from && o2 < e6.to || s2 > e6.from && o2 > e6.to && o2 < e6.from) && (i5 = "pointInBreak"), i5 && r(t3, i5, { point: a3, brk: e6 });
                    }
                  }), p2?.forEach(function(e6) {
                    r(t3, "pointOutsideOfBreak", { point: a3, brk: e6 });
                  });
                });
              });
            }
          }
          function f() {
            let e4 = this.currentDataGrouping, i4 = e4?.gapSize, s2 = this.points.slice(), o2 = this.yAxis, r2 = this.options.gapSize, a2 = s2.length - 1;
            if (r2 && a2 > 0) {
              let e5, n2;
              for ("value" !== this.options.gapUnit && (r2 *= this.basePointRange), i4 && i4 > r2 && i4 >= this.basePointRange && (r2 = i4); a2--; )
                if (n2 && false !== n2.visible || (n2 = s2[a2 + 1]), e5 = s2[a2], false !== n2.visible && false !== e5.visible) {
                  if (n2.x - e5.x > r2) {
                    let i5 = (e5.x + n2.x) / 2;
                    s2.splice(a2 + 1, 0, { isNull: true, x: i5 }), o2.stacking && this.options.stacking && ((o2.stacking.stacks[this.stackKey][i5] = new t2(o2, o2.options.stackLabels, false, i5, this.stack)).total = 0);
                  }
                  n2 = e5;
                }
            }
            return this.getGraphPath(s2);
          }
          e3.compose = function(t3, e4) {
            if (!t3.keepProps.includes("brokenAxis")) {
              t3.keepProps.push("brokenAxis"), s(t3, "init", p), s(t3, "afterInit", i3), s(t3, "afterSetTickPositions", d), s(t3, "afterSetOptions", h);
              let o2 = e4.prototype;
              o2.drawBreaks = g, o2.gappedPath = f, s(e4, "afterGeneratePoints", c), s(e4, "afterRender", u);
            }
            return t3;
          };
          class x {
            static isInBreak(t3, e4) {
              let i4 = t3.repeat || 1 / 0, s2 = t3.from, o2 = t3.to - t3.from, r2 = e4 >= s2 ? (e4 - s2) % i4 : i4 - (s2 - e4) % i4;
              return t3.inclusive ? r2 <= o2 : r2 < o2 && 0 !== r2;
            }
            static lin2Val(t3) {
              let e4 = this.brokenAxis, i4 = e4 && e4.breakArray;
              if (!i4 || !n(t3))
                return t3;
              let s2 = t3, o2, r2;
              for (r2 = 0; r2 < i4.length && !((o2 = i4[r2]).from >= s2); r2++)
                o2.to < s2 ? s2 += o2.len : x.isInBreak(o2, s2) && (s2 += o2.len);
              return s2;
            }
            static val2Lin(t3) {
              let e4 = this.brokenAxis, i4 = e4 && e4.breakArray;
              if (!i4 || !n(t3))
                return t3;
              let s2 = t3, o2, r2;
              for (r2 = 0; r2 < i4.length; r2++)
                if ((o2 = i4[r2]).to <= t3)
                  s2 -= o2.len;
                else if (o2.from >= t3)
                  break;
                else if (x.isInBreak(o2, t3)) {
                  s2 -= t3 - o2.from;
                  break;
                }
              return s2;
            }
            constructor(t3) {
              this.hasBreaks = false, this.axis = t3;
            }
            findBreakAt(t3, e4) {
              return o(e4, function(e5) {
                return e5.from < t3 && t3 < e5.to;
              });
            }
            isInAnyBreak(t3, e4) {
              let i4 = this.axis, s2 = i4.options.breaks || [], o2 = s2.length, r2, a2, h2;
              if (o2 && n(t3)) {
                for (; o2--; )
                  x.isInBreak(s2[o2], t3) && (r2 = true, a2 || (a2 = l(s2[o2].showPoints, !i4.isXAxis)));
                h2 = r2 && e4 ? r2 && !a2 : r2;
              }
              return h2;
            }
            setBreaks(t3, e4) {
              let i4 = this, s2 = i4.axis, o2 = a(t3) && !!t3.length && !!Object.keys(t3[0]).length;
              s2.isDirty = i4.hasBreaks !== o2, i4.hasBreaks = o2, t3 !== s2.options.breaks && (s2.options.breaks = s2.userOptions.breaks = t3), s2.forceRedraw = true, s2.series.forEach(function(t4) {
                t4.isDirty = true;
              }), o2 || s2.val2lin !== x.val2Lin || (delete s2.val2lin, delete s2.lin2val), o2 && (s2.userOptions.ordinal = false, s2.lin2val = x.lin2Val, s2.val2lin = x.val2Lin, s2.setExtremes = function(t4, e5, o3, r2, a2) {
                if (i4.hasBreaks) {
                  let s3;
                  let o4 = this.options.breaks || [];
                  for (; s3 = i4.findBreakAt(t4, o4); )
                    t4 = s3.to;
                  for (; s3 = i4.findBreakAt(e5, o4); )
                    e5 = s3.from;
                  e5 < t4 && (e5 = t4);
                }
                s2.constructor.prototype.setExtremes.call(this, t4, e5, o3, r2, a2);
              }, s2.setAxisTranslation = function() {
                if (s2.constructor.prototype.setAxisTranslation.call(this), i4.unitLength = void 0, i4.hasBreaks) {
                  let t4 = s2.options.breaks || [], e5 = [], o3 = [], a2 = l(s2.pointRangePadding, 0), h2 = 0, d2, p2, c2 = s2.userMin || s2.min, u2 = s2.userMax || s2.max, g2, f2;
                  t4.forEach(function(t5) {
                    p2 = t5.repeat || 1 / 0, n(c2) && n(u2) && (x.isInBreak(t5, c2) && (c2 += t5.to % p2 - c2 % p2), x.isInBreak(t5, u2) && (u2 -= u2 % p2 - t5.from % p2));
                  }), t4.forEach(function(t5) {
                    if (g2 = t5.from, p2 = t5.repeat || 1 / 0, n(c2) && n(u2)) {
                      for (; g2 - p2 > c2; )
                        g2 -= p2;
                      for (; g2 < c2; )
                        g2 += p2;
                      for (f2 = g2; f2 < u2; f2 += p2)
                        e5.push({ value: f2, move: "in" }), e5.push({ value: f2 + t5.to - t5.from, move: "out", size: t5.breakSize });
                    }
                  }), e5.sort(function(t5, e6) {
                    return t5.value === e6.value ? ("in" === t5.move ? 0 : 1) - ("in" === e6.move ? 0 : 1) : t5.value - e6.value;
                  }), d2 = 0, g2 = c2, e5.forEach(function(t5) {
                    1 === (d2 += "in" === t5.move ? 1 : -1) && "in" === t5.move && (g2 = t5.value), 0 === d2 && n(g2) && (o3.push({ from: g2, to: t5.value, len: t5.value - g2 - (t5.size || 0) }), h2 += t5.value - g2 - (t5.size || 0));
                  }), i4.breakArray = o3, n(c2) && n(u2) && n(s2.min) && (i4.unitLength = u2 - c2 - h2 + a2, r(s2, "afterBreaks"), s2.staticScale ? s2.transA = s2.staticScale : i4.unitLength && (s2.transA *= (u2 - s2.min + a2) / i4.unitLength), a2 && (s2.minPixelPadding = s2.transA * (s2.minPointOffset || 0)), s2.min = c2, s2.max = u2);
                }
              }), l(e4, true) && s2.chart.redraw();
            }
          }
          e3.Additions = x;
        }(i2 || (i2 = {})), i2;
      }), i(e, "masters/modules/broken-axis.src.js", [e["Core/Globals.js"], e["Core/Axis/BrokenAxis.js"]], function(t2, e2) {
        return t2.BrokenAxis = t2.BrokenAxis || e2, t2.BrokenAxis.compose(t2.Axis, t2.Series), t2;
      }), i(e, "Extensions/DataGrouping/ApproximationRegistry.js", [], function() {
        return {};
      }), i(e, "Extensions/DataGrouping/ApproximationDefaults.js", [e["Extensions/DataGrouping/ApproximationRegistry.js"], e["Core/Utilities.js"]], function(t2, e2) {
        let { arrayMax: i2, arrayMin: s, correctFloat: o, extend: r, isNumber: a } = e2;
        function n(t3) {
          let e3 = t3.length, i3 = l(t3);
          return a(i3) && e3 && (i3 = o(i3 / e3)), i3;
        }
        function l(t3) {
          let e3 = t3.length, i3;
          if (!e3 && t3.hasNulls)
            i3 = null;
          else if (e3)
            for (i3 = 0; e3--; )
              i3 += t3[e3];
          return i3;
        }
        let h = { average: n, averages: function() {
          let t3 = [];
          return [].forEach.call(arguments, function(e3) {
            t3.push(n(e3));
          }), void 0 === t3[0] ? void 0 : t3;
        }, close: function(t3) {
          return t3.length ? t3[t3.length - 1] : t3.hasNulls ? null : void 0;
        }, high: function(t3) {
          return t3.length ? i2(t3) : t3.hasNulls ? null : void 0;
        }, hlc: function(e3, i3, s2) {
          if (e3 = t2.high(e3), i3 = t2.low(i3), s2 = t2.close(s2), a(e3) || a(i3) || a(s2))
            return [e3, i3, s2];
        }, low: function(t3) {
          return t3.length ? s(t3) : t3.hasNulls ? null : void 0;
        }, ohlc: function(e3, i3, s2, o2) {
          if (e3 = t2.open(e3), i3 = t2.high(i3), s2 = t2.low(s2), o2 = t2.close(o2), a(e3) || a(i3) || a(s2) || a(o2))
            return [e3, i3, s2, o2];
        }, open: function(t3) {
          return t3.length ? t3[0] : t3.hasNulls ? null : void 0;
        }, range: function(e3, i3) {
          return (e3 = t2.low(e3), i3 = t2.high(i3), a(e3) || a(i3)) ? [e3, i3] : null === e3 && null === i3 ? null : void 0;
        }, sum: l };
        return r(t2, h), h;
      }), i(e, "Extensions/DataGrouping/DataGroupingDefaults.js", [], function() {
        return { common: { groupPixelWidth: 2, dateTimeLabelFormats: { millisecond: ["%A, %e %b, %H:%M:%S.%L", "%A, %e %b, %H:%M:%S.%L", "-%H:%M:%S.%L"], second: ["%A, %e %b, %H:%M:%S", "%A, %e %b, %H:%M:%S", "-%H:%M:%S"], minute: ["%A, %e %b, %H:%M", "%A, %e %b, %H:%M", "-%H:%M"], hour: ["%A, %e %b, %H:%M", "%A, %e %b, %H:%M", "-%H:%M"], day: ["%A, %e %b %Y", "%A, %e %b", "-%A, %e %b %Y"], week: ["Week from %A, %e %b %Y", "%A, %e %b", "-%A, %e %b %Y"], month: ["%B %Y", "%B", "-%B %Y"], year: ["%Y", "%Y", "-%Y"] } }, seriesSpecific: { line: {}, spline: {}, area: {}, areaspline: {}, arearange: {}, column: { groupPixelWidth: 10 }, columnrange: { groupPixelWidth: 10 }, candlestick: { groupPixelWidth: 10 }, ohlc: { groupPixelWidth: 5 }, hlc: { groupPixelWidth: 5 }, heikinashi: { groupPixelWidth: 10 } }, units: [["millisecond", [1, 2, 5, 10, 20, 25, 50, 100, 200, 500]], ["second", [1, 2, 5, 10, 15, 30]], ["minute", [1, 2, 5, 10, 15, 30]], ["hour", [1, 2, 3, 4, 6, 8, 12]], ["day", [1]], ["week", [1]], ["month", [1, 3, 6]], ["year", null]] };
      }), i(e, "Extensions/DataGrouping/DataGroupingAxisComposition.js", [e["Extensions/DataGrouping/DataGroupingDefaults.js"], e["Core/Utilities.js"]], function(t2, e2) {
        let i2;
        let { addEvent: s, extend: o, merge: r, pick: a } = e2;
        function n(t3) {
          let e3 = this, i3 = e3.series;
          i3.forEach(function(t4) {
            t4.groupPixelWidth = void 0;
          }), i3.forEach(function(i4) {
            i4.groupPixelWidth = e3.getGroupPixelWidth && e3.getGroupPixelWidth(), i4.groupPixelWidth && (i4.hasProcessed = true), i4.applyGrouping(!!t3.hasExtremesChanged);
          });
        }
        function l() {
          let e3 = this.series, i3 = e3.length, s2 = 0, o2 = false, r2, n2;
          for (; i3--; )
            (n2 = e3[i3].options.dataGrouping) && (s2 = Math.max(s2, a(n2.groupPixelWidth, t2.common.groupPixelWidth)), r2 = (e3[i3].processedXData || e3[i3].data).length, (e3[i3].groupPixelWidth || r2 > this.chart.plotSizeX / s2 || r2 && n2.forced) && (o2 = true));
          return o2 ? s2 : 0;
        }
        function h() {
          this.series.forEach(function(t3) {
            t3.hasProcessed = false;
          });
        }
        function d(t3, e3) {
          let s2;
          if (e3 = a(e3, true), t3 || (t3 = { forced: false, units: null }), this instanceof i2)
            for (s2 = this.series.length; s2--; )
              this.series[s2].update({ dataGrouping: t3 }, false);
          else
            this.chart.options.series.forEach(function(e4) {
              e4.dataGrouping = "boolean" == typeof t3 ? t3 : r(t3, e4.dataGrouping);
            });
          this.ordinal && (this.ordinal.slope = void 0), e3 && this.chart.redraw();
        }
        return { compose: function(t3) {
          i2 = t3;
          let e3 = t3.prototype;
          e3.applyGrouping || (s(t3, "afterSetScale", h), s(t3, "postProcessData", n), o(e3, { applyGrouping: n, getGroupPixelWidth: l, setDataGrouping: d }));
        } };
      }), i(e, "Extensions/DataGrouping/DataGroupingSeriesComposition.js", [e["Extensions/DataGrouping/ApproximationRegistry.js"], e["Extensions/DataGrouping/DataGroupingDefaults.js"], e["Core/Axis/DateTimeAxis.js"], e["Core/Defaults.js"], e["Core/Series/SeriesRegistry.js"], e["Core/Utilities.js"]], function(t2, e2, i2, s, o, r) {
        let { series: { prototype: a } } = o, { addEvent: n, defined: l, error: h, extend: d, isNumber: p, merge: c, pick: u } = r, g = a.generatePoints;
        function f(t3) {
          var s2;
          let o2, r2;
          let n2 = this.chart, d2 = this.options.dataGrouping, c2 = false !== this.allowDG && d2 && u(d2.enabled, n2.options.isStock), g2 = this.reserveSpace(), f2 = this.currentDataGrouping, x2, m2, b2 = false;
          c2 && !this.requireSorting && (this.requireSorting = b2 = true);
          let v2 = false == !(this.isCartesian && !this.isDirty && !this.xAxis.isDirty && !this.yAxis.isDirty && !t3) || !c2;
          if (b2 && (this.requireSorting = false), v2)
            return;
          this.destroyGroupedData();
          let y2 = d2.groupAll ? this.xData : this.processedXData, M = d2.groupAll ? this.yData : this.processedYData, S = n2.plotSizeX, A = this.xAxis, k = A.options.ordinal, C = this.groupPixelWidth;
          if (C && y2 && y2.length && S) {
            r2 = true, this.isDirty = true, this.points = null;
            let t4 = A.getExtremes(), c3 = t4.min, u2 = t4.max, f3 = k && A.ordinal && A.ordinal.getGroupIntervalFactor(c3, u2, this) || 1, b3 = C * (u2 - c3) / S * f3, v3 = A.getTimeTicks(i2.Additions.prototype.normalizeTimeTickInterval(b3, d2.units || e2.units), Math.min(c3, y2[0]), Math.max(u2, y2[y2.length - 1]), A.options.startOfWeek, y2, this.closestPointRange), D = a.groupData.apply(this, [y2, M, v3, d2.approximation]), w = D.groupedXData, O = D.groupedYData, B = 0;
            for (d2 && d2.smoothed && w.length && (d2.firstAnchor = "firstPoint", d2.anchor = "middle", d2.lastAnchor = "lastPoint", h(32, false, n2, { "dataGrouping.smoothed": "use dataGrouping.anchor" })), o2 = 1; o2 < v3.length; o2++)
              v3.info.segmentStarts && -1 !== v3.info.segmentStarts.indexOf(o2) || (B = Math.max(v3[o2] - v3[o2 - 1], B));
            (x2 = v3.info).gapSize = B, this.closestPointRange = v3.info.totalRange, this.groupMap = D.groupMap, this.currentDataGrouping = x2, function(t5, e3, i3) {
              let s3 = t5.options.dataGrouping, o3 = t5.currentDataGrouping && t5.currentDataGrouping.gapSize;
              if (!(s3 && t5.xData && o3 && t5.groupMap))
                return;
              let r3 = e3.length - 1, a2 = s3.anchor, n3 = s3.firstAnchor, l2 = s3.lastAnchor, h2 = e3.length - 1, d3 = 0;
              if (n3 && t5.xData[0] >= e3[0]) {
                let i4;
                d3++;
                let s4 = t5.groupMap[0].start, r4 = t5.groupMap[0].length;
                p(s4) && p(r4) && (i4 = s4 + (r4 - 1)), e3[0] = { start: e3[0], middle: e3[0] + 0.5 * o3, end: e3[0] + o3, firstPoint: t5.xData[0], lastPoint: i4 && t5.xData[i4] }[n3];
              }
              if (r3 > 0 && l2 && o3 && e3[r3] >= i3 - o3) {
                h2--;
                let i4 = t5.groupMap[t5.groupMap.length - 1].start;
                e3[r3] = { start: e3[r3], middle: e3[r3] + 0.5 * o3, end: e3[r3] + o3, firstPoint: i4 && t5.xData[i4], lastPoint: t5.xData[t5.xData.length - 1] }[l2];
              }
              if (a2 && "start" !== a2) {
                let t6 = o3 * { middle: 0.5, end: 1 }[a2];
                for (; h2 >= d3; )
                  e3[h2] += t6, h2--;
              }
            }(this, w, u2), g2 && (l((s2 = w)[0]) && p(A.min) && p(A.dataMin) && s2[0] < A.min && ((!l(A.options.min) && A.min <= A.dataMin || A.min === A.dataMin) && (A.min = Math.min(s2[0], A.min)), A.dataMin = Math.min(s2[0], A.dataMin)), l(s2[s2.length - 1]) && p(A.max) && p(A.dataMax) && s2[s2.length - 1] > A.max && ((!l(A.options.max) && p(A.dataMax) && A.max >= A.dataMax || A.max === A.dataMax) && (A.max = Math.max(s2[s2.length - 1], A.max)), A.dataMax = Math.max(s2[s2.length - 1], A.dataMax))), d2.groupAll && (this.allGroupedData = O, w = (m2 = this.cropData(w, O, A.min, A.max)).xData, O = m2.yData, this.cropStart = m2.start), this.processedXData = w, this.processedYData = O;
          } else
            this.groupMap = null;
          this.hasGroupedData = r2, this.preventGraphAnimation = (f2 && f2.totalRange) !== (x2 && x2.totalRange);
        }
        function x() {
          this.groupedData && (this.groupedData.forEach(function(t3, e3) {
            t3 && (this.groupedData[e3] = t3.destroy ? t3.destroy() : null);
          }, this), this.groupedData.length = 0, delete this.allGroupedData);
        }
        function m() {
          g.apply(this), this.destroyGroupedData(), this.groupedData = this.hasGroupedData ? this.points : null;
        }
        function b() {
          return this.is("arearange") ? "range" : this.is("ohlc") ? "ohlc" : this.is("hlc") ? "hlc" : this.is("column") || this.options.cumulative ? "sum" : "average";
        }
        function v(e3, i3, s2, o2) {
          let r2 = this, a2 = r2.data, n2 = r2.options && r2.options.data, h2 = [], d2 = [], u2 = [], g2 = e3.length, f2 = !!i3, x2 = [], m2 = r2.pointArrayMap, b2 = m2 && m2.length, v2 = ["x"].concat(m2 || ["y"]), y2 = this.options.dataGrouping && this.options.dataGrouping.groupAll, M, S, A, k = 0, C = 0, D = "function" == typeof o2 ? o2 : o2 && t2[o2] ? t2[o2] : t2[r2.getDGApproximation && r2.getDGApproximation() || "average"];
          if (b2) {
            let t3 = m2.length;
            for (; t3--; )
              x2.push([]);
          } else
            x2.push([]);
          let w = b2 || 1;
          for (let t3 = 0; t3 <= g2; t3++)
            if (!(e3[t3] < s2[0])) {
              for (; void 0 !== s2[k + 1] && e3[t3] >= s2[k + 1] || t3 === g2; ) {
                M = s2[k], r2.dataGroupInfo = { start: y2 ? C : r2.cropStart + C, length: x2[0].length, groupStart: M }, A = D.apply(r2, x2), r2.pointClass && !l(r2.dataGroupInfo.options) && (r2.dataGroupInfo.options = c(r2.pointClass.prototype.optionsToObject.call({ series: r2 }, r2.options.data[r2.cropStart + C])), v2.forEach(function(t4) {
                  delete r2.dataGroupInfo.options[t4];
                })), void 0 !== A && (h2.push(M), d2.push(A), u2.push(r2.dataGroupInfo)), C = t3;
                for (let t4 = 0; t4 < w; t4++)
                  x2[t4].length = 0, x2[t4].hasNulls = false;
                if (k += 1, t3 === g2)
                  break;
              }
              if (t3 === g2)
                break;
              if (m2) {
                let e4;
                let i4 = r2.options.dataGrouping && r2.options.dataGrouping.groupAll ? t3 : r2.cropStart + t3, s3 = a2 && a2[i4] || r2.pointClass.prototype.applyOptions.apply({ series: r2 }, [n2[i4]]);
                for (let t4 = 0; t4 < b2; t4++)
                  p(e4 = s3[m2[t4]]) ? x2[t4].push(e4) : null === e4 && (x2[t4].hasNulls = true);
              } else
                p(S = f2 ? i3[t3] : null) ? x2[0].push(S) : null === S && (x2[0].hasNulls = true);
            }
          return { groupedXData: h2, groupedYData: d2, groupMap: u2 };
        }
        function y(t3) {
          let i3 = t3.options, o2 = this.type, r2 = this.chart.options.plotOptions, a2 = this.useCommonDataGrouping && e2.common, n2 = e2.seriesSpecific, l2 = s.defaultOptions.plotOptions[o2].dataGrouping;
          if (r2 && (n2[o2] || a2)) {
            let t4 = this.chart.rangeSelector;
            l2 || (l2 = c(e2.common, n2[o2])), i3.dataGrouping = c(a2, l2, r2.series && r2.series.dataGrouping, r2[o2].dataGrouping, this.userOptions.dataGrouping, !i3.isInternal && t4 && p(t4.selected) && t4.buttonOptions[t4.selected].dataGrouping);
          }
        }
        return { compose: function(t3) {
          let e3 = t3.prototype;
          e3.applyGrouping || (n(t3.prototype.pointClass, "update", function() {
            if (this.dataGroup)
              return h(24, false, this.series.chart), false;
          }), n(t3, "afterSetOptions", y), n(t3, "destroy", x), d(e3, { applyGrouping: f, destroyGroupedData: x, generatePoints: m, getDGApproximation: b, groupData: v }));
        }, groupData: v };
      }), i(e, "Extensions/DataGrouping/DataGrouping.js", [e["Extensions/DataGrouping/DataGroupingAxisComposition.js"], e["Extensions/DataGrouping/DataGroupingDefaults.js"], e["Extensions/DataGrouping/DataGroupingSeriesComposition.js"], e["Core/Templating.js"], e["Core/Globals.js"], e["Core/Utilities.js"]], function(t2, e2, i2, s, o, r) {
        let { format: a } = s, { composed: n } = o, { addEvent: l, extend: h, isNumber: d, pick: p, pushUnique: c } = r;
        function u(t3) {
          let i3 = this.chart, s2 = i3.time, o2 = t3.labelConfig, r2 = o2.series, n2 = o2.point, l2 = r2.options, c2 = r2.tooltipOptions, u2 = l2.dataGrouping, g = r2.xAxis, f = c2.xDateFormat, x, m, b, v, y, M = c2[t3.isFooter ? "footerFormat" : "headerFormat"];
          if (g && "datetime" === g.options.type && u2 && d(o2.key)) {
            m = r2.currentDataGrouping, b = u2.dateTimeLabelFormats || e2.common.dateTimeLabelFormats, m ? (v = b[m.unitName], 1 === m.count ? f = v[0] : (f = v[1], x = v[2])) : !f && b && g.dateTime && (f = g.dateTime.getXDateFormat(o2.x, c2.dateTimeLabelFormats));
            let l3 = p(r2.groupMap?.[n2.index].groupStart, o2.key), d2 = l3 + m?.totalRange - 1;
            y = s2.dateFormat(f, l3), x && (y += s2.dateFormat(x, d2)), r2.chart.styledMode && (M = this.styledModeFormat(M)), t3.text = a(M, { point: h(o2.point, { key: y }), series: r2 }, i3), t3.preventDefault();
          }
        }
        return { compose: function(e3, s2, o2) {
          t2.compose(e3), i2.compose(s2), o2 && c(n, "DataGrouping") && l(o2, "headerFormatter", u);
        }, groupData: i2.groupData };
      }), i(e, "masters/modules/datagrouping.src.js", [e["Core/Globals.js"], e["Extensions/DataGrouping/ApproximationDefaults.js"], e["Extensions/DataGrouping/ApproximationRegistry.js"], e["Extensions/DataGrouping/DataGrouping.js"]], function(t2, e2, i2, s) {
        return t2.dataGrouping = t2.dataGrouping || {}, t2.dataGrouping.approximationDefaults = t2.dataGrouping.approximationDefaults || e2, t2.dataGrouping.approximations = t2.dataGrouping.approximations || i2, s.compose(t2.Axis, t2.Series, t2.Tooltip), t2;
      }), i(e, "Extensions/Annotations/NavigationBindingsUtilities.js", [e["Core/Utilities.js"]], function(t2) {
        let { defined: e2, isNumber: i2, pick: s } = t2, o = { backgroundColor: "string", borderColor: "string", borderRadius: "string", color: "string", fill: "string", fontSize: "string", labels: "string", name: "string", stroke: "string", title: "string" };
        return { annotationsFieldsTypes: o, getAssignedAxis: function(t3) {
          return t3.filter((t4) => {
            let e3 = t4.axis.getExtremes(), o2 = e3.min, r = e3.max, a = s(t4.axis.minPointOffset, 0);
            return i2(o2) && i2(r) && t4.value >= o2 - a && t4.value <= r + a && !t4.axis.options.isInternal;
          })[0];
        }, getFieldType: function(t3, i3) {
          let s2 = o[t3], r = typeof i3;
          return e2(s2) && (r = s2), { string: "text", number: "number", boolean: "checkbox" }[r];
        } };
      }), i(e, "Extensions/MouseWheelZoom/MouseWheelZoom.js", [e["Core/Utilities.js"], e["Extensions/Annotations/NavigationBindingsUtilities.js"]], function(t2, e2) {
        let i2;
        let { addEvent: s, isObject: o, pick: r, defined: a, merge: n } = t2, { getAssignedAxis: l } = e2, h = [], d = { enabled: true, sensitivity: 1.1 }, p = (t3) => (o(t3) || (t3 = { enabled: t3 ?? true }), n(d, t3)), c = function(t3, e3, s2, o2, n2, l2, h2) {
          let d2 = r(h2.type, t3.zooming.type, ""), p2 = [];
          "x" === d2 ? p2 = s2 : "y" === d2 ? p2 = o2 : "xy" === d2 && (p2 = t3.axes);
          let c2 = t3.transform({ axes: p2, to: { x: n2 - 5, y: l2 - 5, width: 10, height: 10 }, from: { x: n2 - 5 * e3, y: l2 - 5 * e3, width: 10 * e3, height: 10 * e3 }, trigger: "mousewheel" });
          return c2 && (a(i2) && clearTimeout(i2), i2 = setTimeout(() => {
            t3.pointer?.drop();
          }, 400)), c2;
        };
        function u() {
          let t3 = p(this.zooming.mouseWheel);
          t3.enabled && s(this.container, "wheel", (e3) => {
            e3 = this.pointer?.normalize(e3) || e3;
            let { pointer: i3 } = this, s2 = i3 && !i3.inClass(e3.target, "highcharts-no-mousewheel");
            if (this.isInsidePlot(e3.chartX - this.plotLeft, e3.chartY - this.plotTop) && s2) {
              let s3 = t3.sensitivity || 1.1, o2 = e3.detail || (e3.deltaY || 0) / 120, r2 = l(i3.getCoordinates(e3).xAxis), a2 = l(i3.getCoordinates(e3).yAxis);
              c(this, Math.pow(s3, o2), r2 ? [r2.axis] : this.xAxis, a2 ? [a2.axis] : this.yAxis, e3.chartX, e3.chartY, t3) && e3.preventDefault?.();
            }
          });
        }
        return { compose: function(t3) {
          -1 === h.indexOf(t3) && (h.push(t3), s(t3, "afterGetContainer", u));
        } };
      }), i(e, "masters/modules/mouse-wheel-zoom.src.js", [e["Core/Globals.js"], e["Extensions/MouseWheelZoom/MouseWheelZoom.js"]], function(t2, e2) {
        return t2.MouseWheelZoom = t2.MouseWheelZoom || e2, t2.MouseWheelZoom.compose(t2.Chart), t2;
      }), i(e, "masters/modules/stock.src.js", [e["Core/Globals.js"], e["Series/DataModifyComposition.js"], e["Stock/Navigator/Navigator.js"], e["Core/Axis/OrdinalAxis.js"], e["Stock/RangeSelector/RangeSelector.js"], e["Stock/Scrollbar/Scrollbar.js"], e["Core/Chart/StockChart.js"], e["Series/OHLC/OHLCSeries.js"], e["Series/Flags/FlagsSeries.js"]], function(t2, e2, i2, s, o, r, a, n, l) {
        return t2.Navigator = t2.Navigator || i2, t2.OrdinalAxis = t2.OrdinalAxis || s, t2.RangeSelector = t2.RangeSelector || o, t2.Scrollbar = t2.Scrollbar || r, t2.stockChart = t2.stockChart || a.stockChart, t2.StockChart = t2.StockChart || t2.stockChart, t2.extend(t2.StockChart, a), e2.compose(t2.Series, t2.Axis, t2.Point), l.compose(t2.Renderer), n.compose(t2.Series), t2.Navigator.compose(t2.Chart, t2.Axis, t2.Series), t2.OrdinalAxis.compose(t2.Axis, t2.Series, t2.Chart), t2.RangeSelector.compose(t2.Axis, t2.Chart), t2.Scrollbar.compose(t2.Axis), t2.StockChart.compose(t2.Chart, t2.Axis, t2.Series, t2.SVGRenderer), t2;
      });
    });
  }
});
export default require_stock();
//# sourceMappingURL=highcharts_modules_stock.js.map
