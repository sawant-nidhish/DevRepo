import {
  __commonJS
} from "./chunk-WKYGNSYM.js";

// node_modules/highcharts/indicators/indicators.js
var require_indicators = __commonJS({
  "node_modules/highcharts/indicators/indicators.js"(exports, module) {
    !/**
    * Highstock JS v11.4.0 (2024-03-04)
    *
    * Indicator series type for Highcharts Stock
    *
    * (c) 2010-2024 Pawel Fus, Sebastian Bochan
    *
    * License: www.highcharts.com/license
    */
    function(t) {
      "object" == typeof module && module.exports ? (t.default = t, module.exports = t) : "function" == typeof define && define.amd ? define("highcharts/indicators/indicators", ["highcharts", "highcharts/modules/stock"], function(e) {
        return t(e), t.Highcharts = e, t;
      }) : t("undefined" != typeof Highcharts ? Highcharts : void 0);
    }(function(t) {
      "use strict";
      var e = t ? t._modules : {};
      function a(t2, e2, a2, i) {
        t2.hasOwnProperty(e2) || (t2[e2] = i.apply(null, a2), "function" == typeof CustomEvent && window.dispatchEvent(new CustomEvent("HighchartsModuleLoaded", { detail: { path: e2, module: t2[e2] } })));
      }
      a(e, "Stock/Indicators/SMA/SMAIndicator.js", [e["Core/Chart/Chart.js"], e["Core/Series/SeriesRegistry.js"], e["Core/Utilities.js"]], function(t2, e2, a2) {
        let { line: i } = e2.seriesTypes, { addEvent: s, fireEvent: n, error: o, extend: r, isArray: l, merge: p, pick: h, splat: u } = a2;
        class c extends i {
          destroy() {
            this.dataEventsToUnbind.forEach(function(t3) {
              t3();
            }), super.destroy.apply(this, arguments);
          }
          getName() {
            let t3 = [], e3 = this.name;
            return e3 || ((this.nameComponents || []).forEach(function(e4, a3) {
              t3.push(this.options.params[e4] + h(this.nameSuffixes[a3], ""));
            }, this), e3 = (this.nameBase || this.type.toUpperCase()) + (this.nameComponents ? " (" + t3.join(", ") + ")" : "")), e3;
          }
          getValues(t3, e3) {
            let a3 = e3.period, i2 = t3.xData, s2 = t3.yData, n2 = s2.length, o2 = [], r2 = [], p2 = [], h2, u2 = -1, c2 = 0, d, f = 0;
            if (!(i2.length < a3)) {
              for (l(s2[0]) && (u2 = e3.index ? e3.index : 0); c2 < a3 - 1; )
                f += u2 < 0 ? s2[c2] : s2[c2][u2], c2++;
              for (h2 = c2; h2 < n2; h2++)
                f += u2 < 0 ? s2[h2] : s2[h2][u2], d = [i2[h2], f / a3], o2.push(d), r2.push(d[0]), p2.push(d[1]), f -= u2 < 0 ? s2[h2 - c2] : s2[h2 - c2][u2];
              return { values: o2, xData: r2, yData: p2 };
            }
          }
          init(e3, a3) {
            let i2 = this;
            super.init.call(i2, e3, a3);
            let n2 = s(t2, "afterLinkSeries", function({ isUpdating: t3 }) {
              if (t3)
                return;
              let a4 = !!i2.dataEventsToUnbind.length;
              if (!i2.linkedParent)
                return o("Series " + i2.options.linkedTo + " not found! Check `linkedTo`.", false, e3);
              if (!a4 && (i2.dataEventsToUnbind.push(s(i2.linkedParent, "updatedData", function() {
                i2.recalculateValues();
              })), i2.calculateOn.xAxis && i2.dataEventsToUnbind.push(s(i2.linkedParent.xAxis, i2.calculateOn.xAxis, function() {
                i2.recalculateValues();
              }))), "init" === i2.calculateOn.chart)
                i2.processedYData || i2.recalculateValues();
              else if (!a4) {
                let t4 = s(i2.chart, i2.calculateOn.chart, function() {
                  i2.recalculateValues(), t4();
                });
              }
            }, { order: 0 });
            i2.dataEventsToUnbind = [], i2.eventsToUnbind.push(n2);
          }
          recalculateValues() {
            let t3 = [], e3 = this.points || [], a3 = (this.xData || []).length, i2 = true, s2, o2, r2, l2, p2, h2, c2 = this.linkedParent.options && this.linkedParent.yData && this.linkedParent.yData.length && this.getValues(this.linkedParent, this.options.params) || { values: [], xData: [], yData: [] };
            if (a3 && !this.hasGroupedData && this.visible && this.points) {
              if (this.cropped) {
                for (this.xAxis && (l2 = this.xAxis.min, p2 = this.xAxis.max), r2 = this.cropData(c2.xData, c2.yData, l2, p2), h2 = 0; h2 < r2.xData.length; h2++)
                  t3.push([r2.xData[h2]].concat(u(r2.yData[h2])));
                s2 = c2.xData.indexOf(this.xData[0]), o2 = c2.xData.indexOf(this.xData[this.xData.length - 1]), -1 === s2 && o2 === c2.xData.length - 2 && t3[0][0] === e3[0].x && t3.shift(), this.updateData(t3);
              } else
                (this.updateAllPoints || c2.xData.length !== a3 - 1 && c2.xData.length !== a3 + 1) && (i2 = false, this.updateData(c2.values));
            }
            i2 && (this.xData = c2.xData, this.yData = c2.yData, this.options.data = c2.values), this.calculateOn.xAxis && this.processedXData && (delete this.processedXData, this.isDirty = true, this.redraw()), this.isDirtyData = !!this.linkedSeries.length, n(this, "updatedData");
          }
          processData() {
            let t3 = this.options.compareToMain, e3 = this.linkedParent;
            super.processData.apply(this, arguments), this.dataModify && e3 && e3.dataModify && e3.dataModify.compareValue && t3 && (this.dataModify.compareValue = e3.dataModify.compareValue);
          }
        }
        return c.defaultOptions = p(i.defaultOptions, { name: void 0, tooltip: { valueDecimals: 4 }, linkedTo: void 0, compareToMain: false, params: { index: 3, period: 14 } }), r(c.prototype, { calculateOn: { chart: "init" }, hasDerivedData: true, nameComponents: ["period"], nameSuffixes: [], useCommonDataGrouping: true }), e2.registerSeriesType("sma", c), c;
      }), a(e, "Stock/Indicators/EMA/EMAIndicator.js", [e["Core/Series/SeriesRegistry.js"], e["Core/Utilities.js"]], function(t2, e2) {
        let { sma: a2 } = t2.seriesTypes, { correctFloat: i, isArray: s, merge: n } = e2;
        class o extends a2 {
          accumulatePeriodPoints(t3, e3, a3) {
            let i2 = 0, s2 = 0;
            for (; s2 < t3; )
              i2 += e3 < 0 ? a3[s2] : a3[s2][e3], s2++;
            return i2;
          }
          calculateEma(t3, e3, a3, s2, n2, o2, r) {
            let l = t3[a3 - 1], p = o2 < 0 ? e3[a3 - 1] : e3[a3 - 1][o2];
            return [l, void 0 === n2 ? r : i(p * s2 + n2 * (1 - s2))];
          }
          getValues(t3, e3) {
            let a3 = e3.period, i2 = t3.xData, n2 = t3.yData, o2 = n2 ? n2.length : 0, r = 2 / (a3 + 1), l = [], p = [], h = [], u, c, d, f = -1, m = 0;
            if (!(o2 < a3)) {
              for (s(n2[0]) && (f = e3.index ? e3.index : 0), m = this.accumulatePeriodPoints(a3, f, n2) / a3, d = a3; d < o2 + 1; d++)
                c = this.calculateEma(i2, n2, d, r, u, f, m), l.push(c), p.push(c[0]), h.push(c[1]), u = c[1];
              return { values: l, xData: p, yData: h };
            }
          }
        }
        return o.defaultOptions = n(a2.defaultOptions, { params: { index: 3, period: 9 } }), t2.registerSeriesType("ema", o), o;
      }), a(e, "Stock/Indicators/MultipleLinesComposition.js", [e["Core/Series/SeriesRegistry.js"], e["Core/Utilities.js"]], function(t2, e2) {
        var a2;
        let { sma: { prototype: i } } = t2.seriesTypes, { defined: s, error: n, merge: o } = e2;
        return function(t3) {
          let e3 = ["bottomLine"], a3 = ["top", "bottom"], r = ["top"];
          function l(t4) {
            return "plot" + t4.charAt(0).toUpperCase() + t4.slice(1);
          }
          function p(t4, e4) {
            let a4 = [];
            return (t4.pointArrayMap || []).forEach((t5) => {
              t5 !== e4 && a4.push(l(t5));
            }), a4;
          }
          function h() {
            let t4 = this, e4 = t4.pointValKey, a4 = t4.linesApiNames, r2 = t4.areaLinesNames, h2 = t4.points, u2 = t4.options, c2 = t4.graph, d2 = { options: { gapSize: u2.gapSize } }, f = [], m = p(t4, e4), x = h2.length, y;
            if (m.forEach((t5, e5) => {
              for (f[e5] = []; x--; )
                y = h2[x], f[e5].push({ x: y.x, plotX: y.plotX, plotY: y[t5], isNull: !s(y[t5]) });
              x = h2.length;
            }), t4.userOptions.fillColor && r2.length) {
              let e5 = f[m.indexOf(l(r2[0]))], a5 = 1 === r2.length ? h2 : f[m.indexOf(l(r2[1]))], s2 = t4.color;
              t4.points = a5, t4.nextPoints = e5, t4.color = t4.userOptions.fillColor, t4.options = o(h2, d2), t4.graph = t4.area, t4.fillGraph = true, i.drawGraph.call(t4), t4.area = t4.graph, delete t4.nextPoints, delete t4.fillGraph, t4.color = s2;
            }
            a4.forEach((e5, a5) => {
              f[a5] ? (t4.points = f[a5], u2[e5] ? t4.options = o(u2[e5].styles, d2) : n('Error: "There is no ' + e5 + ' in DOCS options declared. Check if linesApiNames are consistent with your DOCS line names."'), t4.graph = t4["graph" + e5], i.drawGraph.call(t4), t4["graph" + e5] = t4.graph) : n('Error: "' + e5 + ` doesn't have equivalent in pointArrayMap. To many elements in linesApiNames relative to pointArrayMap."`);
            }), t4.points = h2, t4.options = u2, t4.graph = c2, i.drawGraph.call(t4);
          }
          function u(t4) {
            let e4, a4 = [], s2 = [];
            if (t4 = t4 || this.points, this.fillGraph && this.nextPoints) {
              if ((e4 = i.getGraphPath.call(this, this.nextPoints)) && e4.length) {
                e4[0][0] = "L", a4 = i.getGraphPath.call(this, t4), s2 = e4.slice(0, a4.length);
                for (let t5 = s2.length - 1; t5 >= 0; t5--)
                  a4.push(s2[t5]);
              }
            } else
              a4 = i.getGraphPath.apply(this, arguments);
            return a4;
          }
          function c(t4) {
            let e4 = [];
            return (this.pointArrayMap || []).forEach((a4) => {
              e4.push(t4[a4]);
            }), e4;
          }
          function d() {
            let t4 = this.pointArrayMap, e4 = [], a4;
            e4 = p(this), i.translate.apply(this, arguments), this.points.forEach((i2) => {
              t4.forEach((t5, s2) => {
                a4 = i2[t5], this.dataModify && (a4 = this.dataModify.modifyValue(a4)), null !== a4 && (i2[e4[s2]] = this.yAxis.toPixels(a4, true));
              });
            });
          }
          t3.compose = function(t4) {
            let i2 = t4.prototype;
            return i2.linesApiNames = i2.linesApiNames || e3.slice(), i2.pointArrayMap = i2.pointArrayMap || a3.slice(), i2.pointValKey = i2.pointValKey || "top", i2.areaLinesNames = i2.areaLinesNames || r.slice(), i2.drawGraph = h, i2.getGraphPath = u, i2.toYData = c, i2.translate = d, t4;
          };
        }(a2 || (a2 = {})), a2;
      }), a(e, "masters/indicators/indicators.src.js", [e["Core/Globals.js"], e["Stock/Indicators/MultipleLinesComposition.js"]], function(t2, e2) {
        return t2.MultipleLinesComposition = t2.MultipleLinesComposition || e2, t2;
      });
    });
  }
});
export default require_indicators();
//# sourceMappingURL=highcharts_indicators_indicators.js.map
