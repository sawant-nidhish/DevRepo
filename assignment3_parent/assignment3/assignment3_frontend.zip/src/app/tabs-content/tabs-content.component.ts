import { Component } from '@angular/core';

@Component({
  selector: 'app-tabs-content',
  templateUrl: './tabs-content.component.html',
  styleUrl: './tabs-content.component.css'
})
export class TabsContentComponent {

}
